import { useMemo, useState } from 'react';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  BarChart3,
  Bell,
  CalendarCheck,
  CreditCard,
  Dumbbell,
  Home,
  LayoutGrid,
  LogOut,
  Moon,
  Receipt,
  Search,
  Settings,
  Smartphone,
  Sun,
  Tag,
  UserPlus,
  Users,
  Monitor,
  ChevronRight,
} from 'lucide-react';
import { useGymStore } from '@/src/store/useGymStore';
import { getFeeStatus } from '@/src/lib/feeStatus';
import { formatINR } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Avatar } from '@/src/components/common/Avatar';
import { StatusBadge } from '@/src/components/common/StatusBadge';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { OfflineIndicator, PWAInstallBanner, PWAInstallButton } from '@/src/components/pwa/PWAInstallButton';

interface NavItem {
  to: string;
  label: string;
  icon: typeof Home;
}

const PRIMARY_NAV: NavItem[] = [
  { to: '/dashboard', label: 'Dashboard', icon: Home },
  { to: '/members', label: 'Members', icon: Users },
  { to: '/fees', label: 'Fees', icon: CreditCard },
  { to: '/expenses', label: 'Expenses', icon: Receipt },
  { to: '/attendance', label: 'Attendance', icon: CalendarCheck },
  { to: '/plans', label: 'Plans', icon: Tag },
  { to: '/enquiries', label: 'Enquiries', icon: UserPlus },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
  { to: '/settings', label: 'Settings', icon: Settings },
];

const MORE_ITEMS: NavItem[] = [
  { to: '/attendance', label: 'Attendance & Retention', icon: CalendarCheck },
  { to: '/plans', label: 'Membership Plans', icon: Tag },
  { to: '/enquiries', label: 'Enquiries & Leads', icon: UserPlus },
  { to: '/reports', label: 'Monthly Reports & PDF', icon: BarChart3 },
  { to: '/settings', label: 'Gym Settings', icon: Settings },
];

const ROUTE_TITLES: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/members': 'Members',
  '/fees': 'Fees & Dues',
  '/fees/collect': 'Collect Fee',
  '/expenses': 'Expenses',
  '/attendance': 'Attendance',
  '/plans': 'Plans',
  '/enquiries': 'Enquiries',
  '/reports': 'Reports',
  '/settings': 'Settings',
};

export function AppShell() {
  const location = useLocation();
  const navigate = useNavigate();
  const settings = useGymStore((s) => s.settings);
  const members = useGymStore((s) => s.members);
  const plans = useGymStore((s) => s.plans);
  const toggleDarkMode = useGymStore((s) => s.toggleDarkMode);
  const logoutDemo = useGymStore((s) => s.logoutDemo);

  const [moreOpen, setMoreOpen] = useState(false);
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [phonePreview, setPhonePreview] = useState(false);

  const pageTitle = useMemo(() => {
    if (location.pathname.startsWith('/members/')) return 'Member Profile';
    return ROUTE_TITLES[location.pathname] ?? 'IRON PULSE';
  }, [location.pathname]);

  const dueMembers = useMemo(() => {
    return members
      .map((m) => ({
        member: m,
        fee: getFeeStatus(m, settings.reminderDays),
        plan: plans.find((p) => p.id === m.planId),
      }))
      .filter((item) => item.fee.status === 'overdue' || item.fee.status === 'due-soon')
      .sort((a, b) => a.fee.daysToDue - b.fee.daysToDue);
  }, [members, plans, settings.reminderDays]);

  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return members.slice(0, 6);
    return members
      .filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.phone.includes(q) ||
          m.code.toLowerCase().includes(q)
      )
      .slice(0, 8);
  }, [members, searchQuery]);

  const isMoreRouteActive = MORE_ITEMS.some((item) => location.pathname.startsWith(item.to));

  const shellContent = (
    <div
      className={cn(
        'flex min-h-dvh bg-[var(--bg)] text-[var(--text)]',
        phonePreview && 'h-full min-h-0 overflow-y-auto relative'
      )}
    >
      {/* Desktop Left Sidebar */}
      {!phonePreview && (
        <aside className="no-print hidden md:flex md:w-64 md:shrink-0 md:flex-col bg-[#121316] text-white border-r border-white/10">
          <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#F26A1B] text-white">
              <Dumbbell className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <span className="block text-base font-bold tracking-tight whitespace-nowrap truncate">
                IRON PULSE
              </span>
              <span className="block text-[11px] text-neutral-400 truncate">
                Owner Console
              </span>
            </div>
          </div>

          <nav className="flex-1 space-y-1 px-3 py-4 overflow-y-auto" aria-label="Primary navigation">
            {PRIMARY_NAV.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors whitespace-nowrap',
                      isActive
                        ? 'bg-[#F26A1B] text-white shadow-sm'
                        : 'text-neutral-300 hover:bg-white/8 hover:text-white'
                    )
                  }
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </NavLink>
              );
            })}
          </nav>

          <div className="border-t border-white/10 p-3 space-y-2">
            <button
              type="button"
              onClick={() => setPhonePreview(true)}
              className="flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-medium text-neutral-300 hover:bg-white/8 hover:text-white transition-colors cursor-pointer"
            >
              <Smartphone className="h-4 w-4 shrink-0 text-[#F26A1B]" />
              <span>Mobile Preview Frame</span>
            </button>
            <button
              type="button"
              onClick={() => {
                logoutDemo();
                navigate('/login');
              }}
              className="flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-xs font-medium text-neutral-400 hover:bg-white/8 hover:text-white transition-colors cursor-pointer"
            >
              <LogOut className="h-4 w-4 shrink-0" />
              <span>Switch / Lock Demo</span>
            </button>
          </div>
        </aside>
      )}

      {/* Main Column */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Top Bar (Desktop + Mobile native header) */}
        <header
          className={cn(
            'no-print sticky top-0 z-30 border-b border-[var(--border)] bg-[var(--surface)]/92 backdrop-blur-md pt-safe',
            phonePreview ? 'px-4 py-2.5' : 'px-4 md:px-6 py-2.5 md:py-3'
          )}
        >
          <div className="flex items-center justify-between gap-3">
            {/* Left: Brand/Page Title */}
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#F26A1B] text-white',
                  !phonePreview && 'md:hidden'
                )}
              >
                <Dumbbell className="h-4 w-4" />
              </div>
              <h1 className="text-lg md:text-xl font-bold tracking-tight text-[var(--text)] truncate">
                {pageTitle}
              </h1>
            </div>

            {/* Center/Right: Desktop Search + Actions */}
            <div className="flex items-center gap-2 shrink-0">
              {!phonePreview && (
                <button
                  type="button"
                  onClick={() => setSearchOpen(true)}
                  className="hidden md:flex h-10 w-64 items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--bg)] px-3 text-xs text-[var(--text-muted)] hover:border-[#F26A1B]/50 transition-colors cursor-pointer"
                >
                  <Search className="h-4 w-4 shrink-0" />
                  <span className="truncate">Search member name or phone...</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => setSearchOpen(true)}
                aria-label="Search members"
                className={cn(
                  'flex h-11 w-11 md:h-10 md:w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] hover:bg-[var(--surface-muted)] cursor-pointer',
                  !phonePreview && 'md:hidden'
                )}
              >
                <Search className="h-4 w-4" />
              </button>

              <div className="hidden sm:block">
                <PWAInstallButton compact />
              </div>

              <button
                type="button"
                onClick={toggleDarkMode}
                aria-label={settings.darkMode ? 'Switch to light theme' : 'Switch to dark theme'}
                className="flex h-11 w-11 md:h-10 md:w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] hover:bg-[var(--surface-muted)] transition-colors cursor-pointer"
              >
                {settings.darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </button>

              {/* Notifications bell with real due-fee count */}
              <button
                type="button"
                onClick={() => setAlertsOpen(true)}
                aria-label={`Fee due notifications (${dueMembers.length})`}
                className="relative flex h-11 w-11 md:h-10 md:w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] hover:bg-[var(--surface-muted)] transition-colors cursor-pointer"
              >
                <Bell className="h-4 w-4" />
                {dueMembers.length > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-[#D6403A] px-1 text-[10px] font-bold text-white tabular-nums">
                    {dueMembers.length > 99 ? '99+' : dueMembers.length}
                  </span>
                )}
              </button>

              {!phonePreview && (
                <button
                  type="button"
                  onClick={() => navigate('/settings')}
                  title={settings.ownerName}
                  className="hidden md:flex items-center gap-2 rounded-xl border border-[var(--border)] bg-[var(--surface)] pl-1.5 pr-3 py-1 hover:bg-[var(--surface-muted)] transition-colors cursor-pointer"
                >
                  <Avatar name={settings.ownerName} color="#121316" size="sm" className="h-7 w-7 text-[11px]" />
                  <span className="text-xs font-semibold text-[var(--text)] whitespace-nowrap">
                    {settings.ownerName.split(' ')[0]}
                  </span>
                </button>
              )}
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <main
          className={cn(
            'flex-1 px-4 py-4 md:px-6 md:py-6 pb-24',
            !phonePreview && 'md:pb-8 max-w-[1440px] w-full mx-auto'
          )}
        >
          <PWAInstallBanner />
          <Outlet />
        </main>

        {/* Mobile Bottom Navigation Bar (5 tabs) */}
        <nav
          aria-label="Mobile navigation"
          className={cn(
            'no-print fixed bottom-0 left-0 right-0 z-40 border-t border-[var(--border)] bg-[var(--surface)]/95 backdrop-blur-md pb-safe',
            phonePreview ? 'sticky bottom-0' : 'md:hidden'
          )}
        >
          <div className="grid grid-cols-5 h-16 items-center">
            {[
              { to: '/dashboard', label: 'Home', icon: Home },
              { to: '/members', label: 'Members', icon: Users },
              { to: '/fees', label: 'Fees', icon: CreditCard },
              { to: '/expenses', label: 'Expenses', icon: Receipt },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <NavLink
                  key={tab.to}
                  to={tab.to}
                  className={({ isActive }) =>
                    cn(
                      'flex flex-col items-center justify-center min-h-[44px] gap-0.5 text-[10px] font-semibold transition-colors',
                      isActive ? 'text-[#F26A1B]' : 'text-[var(--text-muted)]'
                    )
                  }
                >
                  <Icon className="h-5 w-5" />
                  <span>{tab.label}</span>
                </NavLink>
              );
            })}

            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              className={cn(
                'flex flex-col items-center justify-center min-h-[44px] gap-0.5 text-[10px] font-semibold transition-colors cursor-pointer',
                isMoreRouteActive ? 'text-[#F26A1B]' : 'text-[var(--text-muted)]'
              )}
            >
              <LayoutGrid className="h-5 w-5" />
              <span>More</span>
            </button>
          </div>
        </nav>
      </div>

      {/* More Sheet (Attendance, Plans, Enquiries, Reports, Settings) */}
      <BottomSheet
        open={moreOpen}
        onClose={() => setMoreOpen(false)}
        title="More Tools"
        subtitle="Operations, leads & gym configuration"
      >
        <div className="space-y-1.5">
          {MORE_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.to}
                type="button"
                onClick={() => {
                  setMoreOpen(false);
                  navigate(item.to);
                }}
                className="flex w-full items-center justify-between rounded-2xl border border-[var(--border)] bg-[var(--surface)] px-4 py-3.5 text-left hover:bg-[var(--surface-muted)] transition-colors cursor-pointer min-h-[52px]"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#F26A1B]/12 text-[#F26A1B]">
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className="text-sm font-semibold text-[var(--text)]">{item.label}</span>
                </div>
                <ChevronRight className="h-4 w-4 text-[var(--text-muted)]" />
              </button>
            );
          })}

          <div className="pt-3 flex items-center justify-between gap-3">
            <PWAInstallButton />
            <button
              type="button"
              onClick={() => {
                setMoreOpen(false);
                logoutDemo();
                navigate('/login');
              }}
              className="flex items-center gap-2 rounded-xl border border-[var(--border)] px-4 py-2.5 text-xs font-semibold text-[var(--text-muted)] hover:text-[var(--text)] cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
              <span>Lock Demo</span>
            </button>
          </div>
        </div>
      </BottomSheet>

      {/* Due Alerts Sheet */}
      <BottomSheet
        open={alertsOpen}
        onClose={() => setAlertsOpen(false)}
        title="Fee Alerts"
        subtitle={`${dueMembers.length} members require follow-up`}
      >
        <div className="space-y-2.5">
          {dueMembers.slice(0, 25).map(({ member, fee, plan }) => (
            <div
              key={member.id}
              onClick={() => {
                setAlertsOpen(false);
                navigate(`/members/${member.id}`);
              }}
              className="flex items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-3 hover:bg-[var(--surface-muted)]/60 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-3 min-w-0">
                <Avatar name={member.name} color={member.avatarColor} size="sm" />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-[var(--text)] truncate">{member.name}</p>
                  <div className="mt-0.5 flex items-center gap-2 text-xs text-[var(--text-muted)]">
                    <span className="tabular-nums font-medium">{formatINR(plan?.price ?? 1500)}</span>
                    <span aria-hidden="true">·</span>
                    <StatusBadge status={fee.status} label={fee.shortLabel} compact />
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <CallButton phone={member.phone} name={member.name} />
                <WhatsAppButton
                  phone={member.phone}
                  name={member.name}
                  amount={plan?.price ?? 1500}
                  dueDate={member.nextDueDate}
                />
              </div>
            </div>
          ))}
        </div>
      </BottomSheet>

      {/* Quick Search Sheet */}
      <BottomSheet
        open={searchOpen}
        onClose={() => setSearchOpen(false)}
        title="Quick Search"
        subtitle="Jump to any member profile or collect fee"
        desktopMode="modal"
      >
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-[var(--text-muted)]" />
            <input
              autoFocus
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Type name, phone, or IP-code..."
              className="h-11 w-full rounded-xl border border-[var(--border)] bg-[var(--bg)] pl-10 pr-4 text-sm text-[var(--text)] focus:outline-none focus:ring-2 focus:ring-[#F26A1B]"
            />
          </div>
          <div className="space-y-1.5">
            {searchResults.map((m) => {
              const fee = getFeeStatus(m, settings.reminderDays);
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setSearchOpen(false);
                    setSearchQuery('');
                    navigate(`/members/${m.id}`);
                  }}
                  className="flex w-full items-center justify-between gap-3 rounded-xl border border-[var(--border)] p-3 text-left hover:bg-[var(--surface-muted)] cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={m.name} color={m.avatarColor} size="sm" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[var(--text)] truncate">{m.name}</p>
                      <p className="text-xs text-[var(--text-muted)] tabular-nums">
                        {m.code} · {m.phone}
                      </p>
                    </div>
                  </div>
                  <StatusBadge status={fee.status} label={fee.shortLabel} compact />
                </button>
              );
            })}
          </div>
        </div>
      </BottomSheet>

      <OfflineIndicator />
    </div>
  );

  if (phonePreview) {
    return (
      <div className="min-h-dvh bg-[#181A20] flex flex-col items-center justify-center p-4 gap-4">
        <div className="flex items-center gap-4 text-white">
          <span className="text-sm font-semibold">Mobile App Preview (390 × 844)</span>
          <button
            type="button"
            onClick={() => setPhonePreview(false)}
            className="inline-flex items-center gap-2 rounded-xl bg-[#F26A1B] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#DF5D12] cursor-pointer"
          >
            <Monitor className="h-3.5 w-3.5" />
            <span>Exit Phone Frame</span>
          </button>
        </div>
        <div className="relative h-[844px] w-[390px] overflow-hidden rounded-[44px] border-[10px] border-[#0A0B0D] bg-[var(--bg)] shadow-2xl">
          {shellContent}
        </div>
      </div>
    );
  }

  return shellContent;
}
