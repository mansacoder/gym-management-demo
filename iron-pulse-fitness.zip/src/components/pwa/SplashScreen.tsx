import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Dumbbell } from 'lucide-react';

export function SplashScreen() {
  const [visible, setVisible] = useState(() => {
    if (typeof window === 'undefined') return false;
    return !sessionStorage.getItem('ipf-splash-shown');
  });

  useEffect(() => {
    if (!visible) return;
    sessionStorage.setItem('ipf-splash-shown', '1');
    const timer = window.setTimeout(() => setVisible(false), 850);
    return () => window.clearTimeout(timer);
  }, [visible]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#121316] text-white"
        >
          <motion.div
            initial={{ scale: 0.88, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col items-center"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-[#F26A1B] text-white shadow-xl">
              <Dumbbell className="h-8 w-8" />
            </div>
            <h1 className="mt-4 text-xl font-bold tracking-tight">IRON PULSE</h1>
            <p className="mt-1 text-xs text-neutral-400">Gym Owner Console</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
