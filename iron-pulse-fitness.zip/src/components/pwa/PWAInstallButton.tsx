import { useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';
import { usePWAInstall, useOnlineStatus } from '@/src/components/pwa/usePWAInstall';
import { Button } from '@/src/components/ui/button';

export function PWAInstallButton({ compact = false }: { compact?: boolean }) {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) return null;

  if (isInstallable) {
    return (
      <Button
        type="button"
        variant={compact ? 'outline' : 'default'}
        size="sm"
        onClick={install}
        className="whitespace-nowrap shrink-0"
      >
        <Download className="h-4 w-4" />
        <span>Install App</span>
      </Button>
    );
  }

  if (isIOS) {
    return (
      <>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setShowIOSGuide(true)}
          className="whitespace-nowrap shrink-0"
        >
          <Smartphone className="h-4 w-4" />
          <span>Add to Home</span>
        </Button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 backdrop-blur-xs">
            <div className="w-full max-w-sm rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-[var(--text)]">
                  Install IRON PULSE on iPhone
                </h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  className="rounded-lg p-1 text-[var(--text-muted)] hover:bg-[var(--surface-muted)]"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <ol className="mt-3 space-y-2 text-sm text-[var(--text-muted)]">
                <li>1. Tap the Share button in Safari toolbar.</li>
                <li>2. Scroll down and tap Add to Home Screen.</li>
                <li>3. Launch IRON PULSE right from your home screen.</li>
              </ol>
              <Button
                type="button"
                className="mt-5 w-full"
                onClick={() => setShowIOSGuide(false)}
              >
                Got it
              </Button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
}

export function PWAInstallBanner() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled || dismissed) return null;
  if (!isInstallable && !isIOS) return null;

  return (
    <>
      <div className="no-print mb-4 flex items-center justify-between gap-3 rounded-2xl border border-[#F26A1B]/25 bg-[#F26A1B]/8 px-4 py-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#121316] text-[#F26A1B]">
            <Smartphone className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-[var(--text)] truncate">
              Install IRON PULSE App
            </p>
            <p className="text-xs text-[var(--text-muted)] truncate">
              Full-screen native feel with offline access
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <Button
            type="button"
            size="sm"
            onClick={() => (isInstallable ? install() : setShowIOSGuide(true))}
          >
            Install
          </Button>
          <button
            type="button"
            onClick={() => setDismissed(true)}
            aria-label="Dismiss install banner"
            className="flex h-9 w-9 items-center justify-center rounded-lg text-[var(--text-muted)] hover:bg-[var(--surface-muted)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-6 shadow-2xl">
            <h3 className="text-base font-bold text-[var(--text)]">
              Install on iPhone / iPad
            </h3>
            <p className="mt-2 text-sm text-[var(--text-muted)]">
              Tap the Safari Share icon, then choose Add to Home Screen for standalone full-screen mode.
            </p>
            <Button
              type="button"
              className="mt-4 w-full"
              onClick={() => setShowIOSGuide(false)}
            >
              Close
            </Button>
          </div>
        </div>
      )}
    </>
  );
}

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="no-print fixed bottom-20 md:bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-[#121316] px-3.5 py-2 text-xs font-semibold text-white shadow-lg border border-white/10">
      <span>Offline Mode · Saved local data active</span>
    </div>
  );
}
