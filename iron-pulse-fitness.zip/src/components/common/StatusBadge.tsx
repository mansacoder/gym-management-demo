import { AlertTriangle, CheckCircle2, Clock, Snowflake } from 'lucide-react';
import type { FeeStatus } from '@/src/types';
import { cn } from '@/src/lib/utils';

interface StatusBadgeProps {
  status: FeeStatus;
  label: string;
  compact?: boolean;
  className?: string;
}

const STYLES: Record<FeeStatus, string> = {
  paid: 'text-[#167952] bg-[#1F9D6B]/12 dark:text-[#3CD296] dark:bg-[#1F9D6B]/20',
  'due-soon': 'text-[#9A7400] bg-[#E8B30C]/16 dark:text-[#F5CA3E] dark:bg-[#E8B30C]/20',
  overdue: 'text-[#B52F29] bg-[#D6403A]/12 dark:text-[#F27671] dark:bg-[#D6403A]/20',
  frozen: 'text-[var(--text-muted)] bg-[var(--surface-muted)]',
};

export function StatusBadge({ status, label, compact = false, className }: StatusBadgeProps) {
  const Icon =
    status === 'paid'
      ? CheckCircle2
      : status === 'due-soon'
        ? Clock
        : status === 'overdue'
          ? AlertTriangle
          : Snowflake;

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-lg font-semibold whitespace-nowrap shrink-0 tabular-nums',
        compact ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs',
        STYLES[status],
        className
      )}
    >
      <Icon className="h-3.5 w-3.5 shrink-0" />
      <span>{label}</span>
    </span>
  );
}
