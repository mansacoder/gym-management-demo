import { MessageCircle, Phone } from 'lucide-react';
import { toast } from 'sonner';
import { buildTelUrl, buildWhatsAppUrl, fillWhatsAppTemplate } from '@/src/lib/formatters';
import { useGymStore } from '@/src/store/useGymStore';
import { cn } from '@/src/lib/utils';

interface CallButtonProps {
  phone: string;
  name?: string;
  showLabel?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

export function CallButton({
  phone,
  name,
  showLabel = false,
  size = 'sm',
  className,
}: CallButtonProps) {
  const dims = size === 'sm' ? 'min-h-[44px] min-w-[44px] md:min-h-[36px] md:min-w-[36px]' : 'h-11 px-4';

  return (
    <a
      href={buildTelUrl(phone)}
      onClick={(e) => {
        e.stopPropagation();
        toast.success(`Dialing ${name ?? phone}`);
      }}
      aria-label={`Call ${name ?? phone}`}
      title={`Call ${name ?? phone}`}
      className={cn(
        'inline-flex items-center justify-center gap-1.5 rounded-xl border border-[var(--border)] bg-[var(--surface)] text-[var(--text)] font-semibold text-xs hover:bg-[var(--surface-muted)] transition-transform active:scale-[0.97] whitespace-nowrap shrink-0',
        showLabel ? 'px-3.5 min-h-[44px] md:min-h-[36px]' : dims,
        className
      )}
    >
      <Phone className="h-4 w-4 shrink-0 text-[#121316] dark:text-white" />
      {showLabel && <span>Call</span>}
    </a>
  );
}

interface WhatsAppButtonProps {
  phone: string;
  name: string;
  amount: number;
  dueDate: string;
  customMessage?: string;
  showLabel?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

export function WhatsAppButton({
  phone,
  name,
  amount,
  dueDate,
  customMessage,
  showLabel = false,
  size = 'sm',
  className,
}: WhatsAppButtonProps) {
  const settings = useGymStore((s) => s.settings);
  const message =
    customMessage ??
    fillWhatsAppTemplate(settings.whatsappTemplate, {
      name,
      amount,
      date: dueDate,
      gymName: settings.gymName,
    });

  const url = buildWhatsAppUrl(phone, message);
  const dims = size === 'sm' ? 'min-h-[44px] min-w-[44px] md:min-h-[36px] md:min-w-[36px]' : 'h-11 px-4';

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      onClick={(e) => {
        e.stopPropagation();
        toast.success(`WhatsApp reminder ready for ${name.split(' ')[0]}`);
      }}
      aria-label={`WhatsApp ${name}`}
      title={`Send WhatsApp reminder to ${name}`}
      className={cn(
        'inline-flex items-center justify-center gap-1.5 rounded-xl bg-[#1F9D6B]/14 text-[#167952] dark:bg-[#1F9D6B]/22 dark:text-[#3CD296] font-semibold text-xs hover:bg-[#1F9D6B]/22 transition-transform active:scale-[0.97] whitespace-nowrap shrink-0',
        showLabel ? 'px-3.5 min-h-[44px] md:min-h-[36px]' : dims,
        className
      )}
    >
      <MessageCircle className="h-4 w-4 shrink-0" />
      {showLabel && <span>WhatsApp</span>}
    </a>
  );
}
