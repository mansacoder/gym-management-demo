import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface StatCardProps {
  label: string;
  value: number;
  formatter?: (val: number) => string;
  subtext?: string;
  icon?: LucideIcon;
  variant?: 'default' | 'orange' | 'ink';
  onClick?: () => void;
  className?: string;
}

function useCountUp(target: number, durationMs = 450) {
  const [display, setDisplay] = useState(target);

  useEffect(() => {
    const startVal = 0;
    const startTime = performance.now();
    let frameId = 0;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / durationMs);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(startVal + (target - startVal) * eased);
      if (progress < 1) {
        frameId = requestAnimationFrame(tick);
      }
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [target, durationMs]);

  return display;
}

export function StatCard({
  label,
  value,
  formatter = (v) => String(Math.round(v)),
  subtext,
  icon: Icon,
  variant = 'default',
  onClick,
  className,
}: StatCardProps) {
  const animated = useCountUp(value);

  const variantClasses =
    variant === 'orange'
      ? 'bg-[#F26A1B] text-white border-[#F26A1B]'
      : variant === 'ink'
        ? 'bg-[#121316] text-white border-[#121316] dark:bg-[#1C1E24] dark:border-[#2C2F3A]'
        : 'bg-[var(--surface)] text-[var(--text)] border-[var(--border)]';

  const mutedClasses =
    variant === 'orange'
      ? 'text-white/85'
      : variant === 'ink'
        ? 'text-neutral-300'
        : 'text-[var(--text-muted)]';

  const iconBg =
    variant === 'orange'
      ? 'bg-white/20 text-white'
      : variant === 'ink'
        ? 'bg-white/12 text-[#F26A1B]'
        : 'bg-[var(--surface-muted)] text-[var(--text)]';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className={cn(
        'rounded-[18px] border p-4 sm:p-5 transition-transform',
        onClick && 'cursor-pointer active:scale-[0.98] hover:shadow-sm',
        variantClasses,
        className
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <p className={cn('text-xs font-medium tracking-tight', mutedClasses)}>
          {label}
        </p>
        {Icon && (
          <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-xl', iconBg)}>
            <Icon className="h-4 w-4" />
          </div>
        )}
      </div>
      <div className="mt-2.5 text-2xl sm:text-[28px] font-bold tracking-tight tabular-nums leading-none">
        {formatter(animated)}
      </div>
      {subtext && (
        <p className={cn('mt-2 text-xs truncate', mutedClasses)}>{subtext}</p>
      )}
    </motion.div>
  );
}
