import { CheckCircle2, MessageCircle, Printer } from 'lucide-react';
import { toast } from 'sonner';
import type { Payment } from '@/src/types';
import { useGymStore } from '@/src/store/useGymStore';
import { buildWhatsAppUrl, formatDisplayDate, formatINR, formatPhoneDisplay } from '@/src/lib/formatters';
import { buildReceiptQrMatrix } from '@/src/lib/receipt';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { Button } from '@/src/components/ui/button';

interface ReceiptModalProps {
  payment: Payment | null;
  onClose: () => void;
}

export function ReceiptModal({ payment, onClose }: ReceiptModalProps) {
  const settings = useGymStore((s) => s.settings);
  const member = useGymStore((s) => s.members.find((m) => m.id === payment?.memberId));

  if (!payment) return null;

  const qrMatrix = buildReceiptQrMatrix(`${payment.receiptNo}|${payment.totalPaid}|${payment.date}`);
  const whatsappMessage = `Hi ${payment.memberName.split(' ')[0]}, thank you for your payment of ${formatINR(payment.totalPaid)} at ${settings.gymName}. Receipt No: ${payment.receiptNo}. Plan valid till ${formatDisplayDate(payment.periodEnd)}.`;
  const waUrl = member ? buildWhatsAppUrl(member.phone, whatsappMessage) : '#';

  return (
    <BottomSheet
      open={Boolean(payment)}
      onClose={onClose}
      title="Payment Receipt"
      subtitle={payment.receiptNo}
      desktopMode="modal"
      maxWidthClass="md:max-w-md"
      footer={
        <div className="flex items-center gap-2.5">
          <Button
            type="button"
            variant="outline"
            className="flex-1"
            onClick={() => {
              window.print();
            }}
          >
            <Printer className="h-4 w-4" />
            <span>Print / PDF</span>
          </Button>
          {member && (
            <Button type="button" variant="whatsapp" className="flex-1" asChild>
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => toast.success('Receipt opened for WhatsApp')}
              >
                <MessageCircle className="h-4 w-4" />
                <span>Send on WhatsApp</span>
              </a>
            </Button>
          )}
        </div>
      }
    >
      <div className="space-y-4">
        {/* Confirmation strip */}
        <div className="no-print flex items-center gap-3 rounded-2xl bg-[#1F9D6B]/10 p-3.5 text-[#167952] dark:text-[#3CD296]">
          <CheckCircle2 className="h-5 w-5 shrink-0" />
          <div>
            <p className="text-sm font-bold">Payment Recorded</p>
            <p className="text-xs opacity-90">
              Membership extended till {formatDisplayDate(payment.periodEnd)}
            </p>
          </div>
        </div>

        {/* Printable Receipt Card */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <div className="flex items-start justify-between gap-3 border-b border-dashed border-[var(--border)] pb-4">
            <div>
              <p className="text-base font-bold tracking-tight text-[var(--text)]">
                {settings.gymName}
              </p>
              <p className="mt-0.5 text-[11px] text-[var(--text-muted)] max-w-[220px]">
                {settings.address}
              </p>
              <p className="mt-1 text-[11px] text-[var(--text-muted)] tabular-nums">
                {formatPhoneDisplay(settings.phone)}
              </p>
            </div>

            {/* Deterministic SVG QR */}
            <div className="shrink-0 rounded-xl border border-[var(--border)] bg-white p-1.5">
              <svg width="56" height="56" viewBox="0 0 21 21" aria-label="Receipt verification QR">
                {qrMatrix.map((row, r) =>
                  row.map((filled, c) =>
                    filled ? (
                      <rect key={`${r}-${c}`} x={c} y={r} width={1} height={1} fill="#121316" />
                    ) : null
                  )
                )}
              </svg>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-y-2.5 text-xs">
            <div>
              <p className="text-[var(--text-muted)]">Receipt No</p>
              <p className="font-semibold text-[var(--text)] tabular-nums">{payment.receiptNo}</p>
            </div>
            <div className="text-right">
              <p className="text-[var(--text-muted)]">Date</p>
              <p className="font-semibold text-[var(--text)] tabular-nums">
                {formatDisplayDate(payment.date)}
              </p>
            </div>
            <div>
              <p className="text-[var(--text-muted)]">Member</p>
              <p className="font-semibold text-[var(--text)]">{payment.memberName}</p>
            </div>
            <div className="text-right">
              <p className="text-[var(--text-muted)]">Payment Mode</p>
              <p className="font-semibold text-[var(--text)]">{payment.mode}</p>
            </div>
          </div>

          <div className="mt-4 space-y-2 border-t border-dashed border-[var(--border)] pt-4 text-xs">
            <div className="flex justify-between">
              <span className="text-[var(--text-muted)]">{payment.planName} Plan</span>
              <span className="font-medium tabular-nums">{formatINR(payment.amount)}</span>
            </div>
            {payment.admissionFee > 0 && (
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Admission Fee</span>
                <span className="font-medium tabular-nums">{formatINR(payment.admissionFee)}</span>
              </div>
            )}
            {payment.ptAddonFee > 0 && (
              <div className="flex justify-between">
                <span className="text-[var(--text-muted)]">Personal Training Add-on</span>
                <span className="font-medium tabular-nums">{formatINR(payment.ptAddonFee)}</span>
              </div>
            )}
            {payment.discount > 0 && (
              <div className="flex justify-between text-[#1F9D6B]">
                <span>Discount</span>
                <span className="font-medium tabular-nums">-{formatINR(payment.discount)}</span>
              </div>
            )}
            <div className="flex justify-between border-t border-[var(--border)] pt-2.5 text-sm font-bold text-[var(--text)]">
              <span>Total Paid</span>
              <span className="tabular-nums">{formatINR(payment.totalPaid)}</span>
            </div>
          </div>

          <p className="mt-4 text-center text-[11px] text-[var(--text-muted)]">
            Valid Period: {formatDisplayDate(payment.periodStart)} – {formatDisplayDate(payment.periodEnd)}
          </p>
        </div>
      </div>
    </BottomSheet>
  );
}
