import { useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  desktopMode?: 'drawer' | 'modal';
  maxWidthClass?: string;
}

export function BottomSheet({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  desktopMode = 'drawer',
  maxWidthClass = 'md:max-w-lg',
}: BottomSheetProps) {
  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/55 backdrop-blur-[2px]"
            aria-hidden="true"
          />

          {/* Mobile bottom sheet / Desktop drawer or modal */}
          <motion.div
            initial={{ y: 48, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 48, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            role="dialog"
            aria-modal="true"
            aria-label={title}
            className={cn(
              'relative z-10 flex w-full flex-col bg-[var(--surface)] text-[var(--text)] border border-[var(--border)] shadow-2xl',
              'rounded-t-3xl max-h-[88dvh]',
              desktopMode === 'drawer'
                ? 'md:fixed md:right-0 md:top-0 md:bottom-0 md:h-dvh md:max-h-dvh md:rounded-none md:rounded-l-3xl md:w-full'
                : 'md:rounded-2xl md:max-h-[85vh] md:mx-4',
              maxWidthClass
            )}
          >
            {/* Mobile Drag Handle */}
            <div className="flex justify-center pt-3 pb-1 md:hidden">
              <span className="h-1.5 w-10 rounded-full bg-[var(--border)]" />
            </div>

            {/* Header */}
            <div className="flex items-start justify-between gap-4 border-b border-[var(--border)] px-5 py-4">
              <div className="min-w-0">
                <h2 className="text-lg font-bold tracking-tight text-[var(--text)] truncate">
                  {title}
                </h2>
                {subtitle && (
                  <p className="mt-0.5 text-xs text-[var(--text-muted)] truncate">
                    {subtitle}
                  </p>
                )}
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Close panel"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--surface-muted)] hover:text-[var(--text)] transition-colors cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto px-5 py-4">{children}</div>

            {/* Sticky Footer */}
            {footer && (
              <div className="border-t border-[var(--border)] bg-[var(--surface)] px-5 py-3.5 pb-safe">
                {footer}
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
