import { addDays, addMonths, format, startOfDay, startOfMonth, subDays, subMonths } from 'date-fns';
import type {
  AttendanceRecord,
  BodyStatLog,
  Enquiry,
  Expense,
  ExpenseCategory,
  GymSettings,
  LeadSource,
  LeadStage,
  Member,
  MembershipPlan,
  MemberStatus,
  Payment,
  PaymentMode,
  Trainer,
} from '@/src/types';
import { generateReceiptNumber } from '@/src/lib/receipt';

function createRng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

const FIRST_NAMES_M = [
  'Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh', 'Ayaan',
  'Krishna', 'Ishaan', 'Rohan', 'Vikram', 'Siddharth', 'Karan', 'Nikhil',
  'Rahul', 'Varun', 'Pranav', 'Harsh', 'Dev', 'Manish', 'Deepak', 'Suresh',
  'Rajesh', 'Amit', 'Gaurav', 'Tushar', 'Yash', 'Akash', 'Kunal', 'Mayank',
  'Tarun', 'Nitin', 'Pankaj', 'Abhishek', 'Ankit', 'Sagar', 'Mohit', 'Chetan',
  'Lakshya',
];

const FIRST_NAMES_F = [
  'Ananya', 'Diya', 'Priya', 'Sneha', 'Kavya', 'Neha', 'Pooja', 'Riya',
  'Shruti', 'Megha', 'Tanvi', 'Aditi', 'Nisha', 'Swati', 'Komal', 'Aishwarya',
  'Divya', 'Sakshi', 'Bhavna', 'Roshni', 'Isha', 'Mansi', 'Pallavi', 'Simran',
];

const LAST_NAMES = [
  'Sharma', 'Verma', 'Patel', 'Nair', 'Iyer', 'Reddy', 'Kulkarni', 'Deshmukh',
  'Singh', 'Malhotra', 'Joshi', 'Gupta', 'Mehta', 'Kapoor', 'Agarwal', 'Bhatia',
  'Chauhan', 'Rao', 'Menon', 'Pillai', 'Bansal', 'Saxena', 'Kamble', 'Jain',
  'Chopra', 'Khanna', 'Trivedi', 'Tiwari', 'Mishra', 'Sinha',
];

const AVATAR_COLORS = [
  '#121316', '#F26A1B', '#1F9D6B', '#2C5282', '#9C4221', '#285E61', '#744210', '#4A5568',
];

export const INITIAL_SETTINGS: GymSettings = {
  gymName: 'IRON PULSE FITNESS',
  tagline: 'Strength · Conditioning · Transformation',
  address: '2nd Floor, Horizon Plaza, Indiranagar 100ft Rd, Bengaluru 560038',
  phone: '9845011223',
  gstin: '29AABCI4412K1Z5',
  ownerName: 'Vikramaditya Rao',
  reminderDays: 7,
  whatsappTemplate:
    'Hi {name}, your gym fee of ₹{amount} is due on {date}. Please renew at the desk or via UPI. – {gymName}',
  darkMode: false,
};

export const INITIAL_TRAINERS: Trainer[] = [
  {
    id: 'trn-1',
    name: 'Raghavendra Rao',
    specialty: 'Strength & Powerlifting',
    phone: '9845123401',
    avatarColor: '#121316',
  },
  {
    id: 'trn-2',
    name: 'Meera Nair',
    specialty: 'Fat Loss & Mobility',
    phone: '9845123402',
    avatarColor: '#F26A1B',
  },
  {
    id: 'trn-3',
    name: 'Kabir Malhotra',
    specialty: 'HIIT & Functional Conditioning',
    phone: '9845123403',
    avatarColor: '#1F9D6B',
  },
];

export const INITIAL_PLANS: MembershipPlan[] = [
  {
    id: 'plan-monthly',
    name: 'Monthly',
    durationMonths: 1,
    price: 1500,
    admissionFee: 500,
    description: 'Full floor & cardio access billed every 30 days',
    active: true,
  },
  {
    id: 'plan-quarterly',
    name: 'Quarterly',
    durationMonths: 3,
    price: 4000,
    admissionFee: 500,
    description: '3-month transformation commitment with diet check-in',
    active: true,
  },
  {
    id: 'plan-halfyearly',
    name: 'Half-Yearly',
    durationMonths: 6,
    price: 7500,
    admissionFee: 300,
    description: '6-month access plus 2 complimentary body composition scans',
    active: true,
  },
  {
    id: 'plan-yearly',
    name: 'Yearly',
    durationMonths: 12,
    price: 13500,
    admissionFee: 0,
    description: 'Best value annual membership with zero admission fee',
    active: true,
  },
  {
    id: 'plan-pt',
    name: 'Personal Training',
    durationMonths: 1,
    price: 3500,
    admissionFee: 0,
    isAddon: true,
    description: '12 one-on-one coached sessions per month add-on',
    active: true,
  },
];

export interface SeedBundle {
  settings: GymSettings;
  trainers: Trainer[];
  plans: MembershipPlan[];
  members: Member[];
  payments: Payment[];
  expenses: Expense[];
  attendance: AttendanceRecord[];
  enquiries: Enquiry[];
}

export function generateSeedData(referenceDate: Date = new Date()): SeedBundle {
  const rng = createRng(20261113);
  const today = startOfDay(referenceDate);
  const todayIso = format(today, 'yyyy-MM-dd');
  const currentMonthStart = startOfMonth(today);

  const pick = <T,>(arr: T[]): T => arr[Math.floor(rng() * arr.length)];
  const corePlans = INITIAL_PLANS.filter((p) => !p.isAddon);
  const ptPlan = INITIAL_PLANS.find((p) => p.isAddon)!;

  const members: Member[] = [];
  const payments: Payment[] = [];
  let receiptSeq = 1001;

  const usedPhones = new Set<string>();
  const makePhone = () => {
    let p = '';
    do {
      const prefix = pick(['98', '97', '99', '96', '94', '93', '91', '90']);
      const tail = String(Math.floor(10000000 + rng() * 89999999));
      p = prefix + tail;
    } while (usedPhones.has(p));
    usedPhones.add(p);
    return p;
  };

  // Distribution for 120 members:
  // 0..74 (75 members ~62.5%): Paid (due in 9..180 days)
  // 75..98 (24 members 20%): Due soon (due in 0..7 days)
  // 99..115 (17 members ~14.2%): Overdue (due -1..-24 days)
  // 116..119 (4 members ~3.3%): Frozen
  const totalMembers = 120;

  for (let i = 0; i < totalMembers; i++) {
    const isFemale = rng() < 0.36;
    const first = isFemale ? pick(FIRST_NAMES_F) : pick(FIRST_NAMES_M);
    const last = pick(LAST_NAMES);
    const name = `${first} ${last}`;
    const phone = makePhone();
    const emergencyContact = makePhone();

    // Weight plan choices: Monthly 38%, Quarterly 32%, Half-Yearly 18%, Yearly 12%
    const planRoll = rng();
    const plan =
      planRoll < 0.38
        ? corePlans[0]
        : planRoll < 0.7
          ? corePlans[1]
          : planRoll < 0.88
            ? corePlans[2]
            : corePlans[3];

    const trainer = pick(INITIAL_TRAINERS);
    const ptAddon = rng() < 0.16;

    // Join date: ensure ~12-15 new joinings in current month, rest spread across past 11 months
    let joinDateObj: Date;
    if (i < 13) {
      const daysInCurrentMonth = Math.max(1, today.getDate());
      const dayOffset = Math.floor(rng() * daysInCurrentMonth);
      joinDateObj = addDays(currentMonthStart, dayOffset);
      if (joinDateObj > today) joinDateObj = today;
    } else {
      const monthsBack = 1 + Math.floor(rng() * 11);
      const dayBack = Math.floor(rng() * 26);
      joinDateObj = subDays(subMonths(today, monthsBack), dayBack);
    }

    let nextDueObj: Date;
    let status: MemberStatus = 'active';

    if (i < 75) {
      // Paid / Green
      const maxAhead = Math.min(plan.durationMonths * 30, 140);
      const daysAhead = 9 + Math.floor(rng() * Math.max(15, maxAhead - 9));
      nextDueObj = addDays(today, daysAhead);
      status = 'active';
    } else if (i < 99) {
      // Due soon / Yellow (0..7 days)
      const daysAhead = Math.floor(rng() * 8);
      nextDueObj = addDays(today, daysAhead);
      status = 'expiring';
    } else if (i < 116) {
      // Overdue / Red (-1..-22 days)
      const daysAgo = 1 + Math.floor(rng() * 22);
      nextDueObj = subDays(today, daysAgo);
      status = 'expired';
    } else {
      // Frozen
      nextDueObj = addDays(today, 22 + Math.floor(rng() * 35));
      status = 'frozen';
    }

    // Body stats history (2 to 4 entries)
    const baseWeight = isFemale ? 54 + rng() * 18 : 66 + rng() * 26;
    const statsCount = 2 + Math.floor(rng() * 3);
    const bodyStats: BodyStatLog[] = [];
    for (let s = 0; s < statsCount; s++) {
      const statDate = subDays(today, (statsCount - 1 - s) * 24 + Math.floor(rng() * 5));
      const delta = (s - (statsCount - 1)) * (0.4 + rng() * 0.7);
      bodyStats.push({
        id: `bs-${i}-${s}`,
        date: format(statDate, 'yyyy-MM-dd'),
        weightKg: Number((baseWeight - delta).toFixed(1)),
        bodyFatPct: Number((isFemale ? 25 - s * 0.6 + rng() * 2 : 19 - s * 0.7 + rng() * 2).toFixed(1)),
        waistIn: Number((isFemale ? 29 - s * 0.3 : 33 - s * 0.4).toFixed(1)),
      });
    }

    const memberId = `mem-${String(i + 1).padStart(3, '0')}`;
    const member: Member = {
      id: memberId,
      code: `IP-${1001 + i}`,
      name,
      phone,
      email: `${first.toLowerCase()}.${last.toLowerCase()}@example.in`,
      gender: isFemale ? 'F' : 'M',
      planId: plan.id,
      trainerId: trainer.id,
      joinDate: format(joinDateObj, 'yyyy-MM-dd'),
      nextDueDate: format(nextDueObj, 'yyyy-MM-dd'),
      status,
      emergencyContact,
      notes: pick([
        'Morning 6:30 AM batch · Focus on hypertrophy',
        'Evening 7:00 PM regular · Knee warm-up advised',
        'Targets 5kg fat loss over next 90 days',
        'Prefers UPI reminders before 10 AM',
        'Consistent 4x/week strength split',
      ]),
      bodyStats,
      ptAddon,
      avatarColor: AVATAR_COLORS[i % AVATAR_COLORS.length],
    };
    members.push(member);

    // Seed historical payments for this member from joinDate up to current cycle
    const modes: PaymentMode[] = ['UPI', 'UPI', 'UPI', 'Cash', 'Card'];
    let payCursor = joinDateObj;
    let isFirst = true;
    while (payCursor <= today) {
      // Do not create a payment this month if member is currently overdue from last month
      const isSameMonthAsToday =
        payCursor.getFullYear() === today.getFullYear() &&
        payCursor.getMonth() === today.getMonth();

      if (i >= 99 && i < 116 && isSameMonthAsToday) {
        break;
      }

      const periodEndObj = addMonths(payCursor, plan.durationMonths);
      const admission = isFirst ? plan.admissionFee : 0;
      const ptFee = ptAddon ? ptPlan.price : 0;
      const discount = rng() < 0.15 ? 200 : 0;
      const totalPaid = plan.price + admission + ptFee - discount;
      const payDateStr = format(payCursor, 'yyyy-MM-dd');

      payments.push({
        id: `pay-${receiptSeq}`,
        receiptNo: generateReceiptNumber(receiptSeq, payDateStr),
        memberId: member.id,
        memberName: member.name,
        planId: plan.id,
        planName: plan.name,
        amount: plan.price,
        discount,
        admissionFee: admission,
        ptAddonFee: ptFee,
        totalPaid,
        mode: pick(modes),
        date: payDateStr,
        periodStart: payDateStr,
        periodEnd: format(periodEndObj, 'yyyy-MM-dd'),
        note: isFirst ? 'New membership + admission' : 'Membership renewal',
      });
      receiptSeq++;
      isFirst = false;
      payCursor = addMonths(payCursor, plan.durationMonths);
    }
  }

  // Ensure a few crisp recent payments in the last 3 days of the current month for immediate dashboard activity
  for (let k = 0; k < 5; k++) {
    const m = members[k];
    const pDate = format(subDays(today, k % 3), 'yyyy-MM-dd');
    const plan = corePlans.find((p) => p.id === m.planId) ?? corePlans[0];
    payments.push({
      id: `pay-${receiptSeq}`,
      receiptNo: generateReceiptNumber(receiptSeq, pDate),
      memberId: m.id,
      memberName: m.name,
      planId: plan.id,
      planName: plan.name,
      amount: plan.price,
      discount: 0,
      admissionFee: 0,
      ptAddonFee: m.ptAddon ? ptPlan.price : 0,
      totalPaid: plan.price + (m.ptAddon ? ptPlan.price : 0),
      mode: k % 3 === 0 ? 'UPI' : k % 3 === 1 ? 'Cash' : 'Card',
      date: pDate,
      periodStart: pDate,
      periodEnd: m.nextDueDate,
      note: 'Renewal collected at desk',
    });
    receiptSeq++;
  }

  // Sort payments descending by date
  payments.sort((a, b) => (a.date < b.date ? 1 : -1));

  // 12 months of realistic gym expenses
  const expenses: Expense[] = [];
  let expId = 1;
  for (let mOffset = 11; mOffset >= 0; mOffset--) {
    const monthDate = startOfMonth(subMonths(today, mOffset));
    const mStr = (day: number) => {
      const clampedDay = Math.min(day, mOffset === 0 ? today.getDate() : 28);
      return format(addDays(monthDate, Math.max(0, clampedDay - 1)), 'yyyy-MM-dd');
    };

    const addExp = (
      title: string,
      category: ExpenseCategory,
      amount: number,
      day: number,
      mode: PaymentMode,
      recurring: boolean,
      note: string
    ) => {
      expenses.push({
        id: `exp-${expId++}`,
        title,
        category,
        amount,
        date: mStr(day),
        mode,
        recurring,
        note,
      });
    };

    addExp('Facility Monthly Rent', 'Rent', 52000, 1, 'UPI', true, 'Horizon Plaza 2nd floor lease');
    addExp('Trainers & Front Desk Payroll', 'Salaries', 46000 + (11 - mOffset) * 500, 3, 'UPI', true, '3 coaches + 1 reception staff');
    addExp('BESCOM Electricity & AC Bill', 'Electricity', 11500 + Math.floor(rng() * 3200), 5, 'UPI', true, 'Commercial meter + cardio cooling');

    if (mOffset % 2 === 0) {
      addExp('Cable & Treadmill Belt Servicing', 'Maintenance', 3200 + Math.floor(rng() * 1400), 8, 'Cash', false, 'Preventive floor checkup');
    }
    if (mOffset % 3 === 0) {
      addExp('Kettlebells & Resistance Bands Restock', 'Equipment', 8500 + Math.floor(rng() * 3500), 11, 'Card', false, 'Floor gear upgrade');
    }
    if (rng() < 0.7) {
      addExp('Instagram Local Lead Ads', 'Marketing', 3500 + Math.floor(rng() * 1500), 9, 'Card', false, 'Radius 4km local campaign');
    }
    addExp('Water Dispenser, Sanitizers & Towels', 'Other', 2400 + Math.floor(rng() * 800), 6, 'Cash', true, 'Daily gym consumables');
    if (mOffset <= 4) {
      addExp('Whey & Pre-workout Counter Stock', 'Supplements', 6200, 4, 'UPI', false, 'Member retail shelf');
    }
  }
  expenses.sort((a, b) => (a.date < b.date ? 1 : -1));

  // 60 days of attendance records
  const attendance: AttendanceRecord[] = [];
  let attId = 1;
  const activeMembers = members.filter((m) => m.status !== 'frozen');
  // Reserve indices 60..71 as "absent 8+ days" for the retention feature
  const regularMembers = activeMembers.filter((_, idx) => idx < 60 || idx > 72);

  for (let d = 59; d >= 0; d--) {
    const dayObj = subDays(today, d);
    const dayIso = format(dayObj, 'yyyy-MM-dd');
    const isSunday = dayObj.getDay() === 0;
    const dailyCount = isSunday ? 14 : 26 + Math.floor(rng() * 14);
    const pickedIds = new Set<string>();

    for (let c = 0; c < dailyCount; c++) {
      const m = pick(regularMembers);
      if (pickedIds.has(m.id)) continue;
      pickedIds.add(m.id);

      const isMorning = rng() < 0.54;
      const hour = isMorning ? 6 + Math.floor(rng() * 4) : 17 + Math.floor(rng() * 4);
      const min = Math.floor(rng() * 60);
      const timeStr = `${String(hour).padStart(2, '0')}:${String(min).padStart(2, '0')}`;

      attendance.push({
        id: `att-${attId++}`,
        memberId: m.id,
        date: dayIso,
        checkInTime: timeStr,
      });
    }
  }

  // Ensure the 12 retention-watch members have their last visit 9..20 days ago
  for (let idx = 60; idx <= 72 && idx < activeMembers.length; idx++) {
    const m = activeMembers[idx];
    const lastVisit = format(subDays(today, 9 + (idx - 60)), 'yyyy-MM-dd');
    attendance.push({
      id: `att-${attId++}`,
      memberId: m.id,
      date: lastVisit,
      checkInTime: '07:15',
    });
  }

  // Ensure at least 18 check-ins today so today's log is crisp
  const todayCount = attendance.filter((a) => a.date === todayIso).length;
  if (todayCount < 18) {
    for (let j = 0; j < 18 - todayCount; j++) {
      const m = regularMembers[j];
      if (!attendance.some((a) => a.date === todayIso && a.memberId === m.id)) {
        attendance.push({
          id: `att-${attId++}`,
          memberId: m.id,
          date: todayIso,
          checkInTime: `0${6 + (j % 3)}:${String((j * 11) % 60).padStart(2, '0')}`,
        });
      }
    }
  }

  // 15 realistic Enquiries (Leads)
  const leadSeed: Array<{
    name: string;
    source: LeadSource;
    stage: LeadStage;
    planId: string;
    daysAgo: number;
    note: string;
  }> = [
    { name: 'Rishabh Kulkarni', source: 'Walk-in', stage: 'new', planId: 'plan-quarterly', daysAgo: 0, note: 'Visited evening 6 PM, wants fat loss coaching' },
    { name: 'Shreya Banerjee', source: 'Instagram', stage: 'new', planId: 'plan-monthly', daysAgo: 1, note: 'DM enquiry for morning Zumba + strength' },
    { name: 'Atharv Deshpande', source: 'Referral', stage: 'contacted', planId: 'plan-halfyearly', daysAgo: 2, note: 'Referred by Aarav Sharma, requested weekend trial' },
    { name: 'Nandini Gowda', source: 'Google', stage: 'trial', planId: 'plan-quarterly', daysAgo: 3, note: 'Completed Day 1 trial with Meera Nair' },
    { name: 'Pratik Bhosale', source: 'Walk-in', stage: 'trial', planId: 'plan-yearly', daysAgo: 2, note: 'Interested in Annual plan + locker' },
    { name: 'Zoya Khan', source: 'Instagram', stage: 'contacted', planId: 'plan-monthly', daysAgo: 4, note: 'Asked for couple discount' },
    { name: 'Mayur Shetty', source: 'Google', stage: 'new', planId: 'plan-quarterly', daysAgo: 1, note: 'Lives 500m away, evening batch' },
    { name: 'Kriti Agarwal', source: 'Referral', stage: 'joined', planId: 'plan-quarterly', daysAgo: 5, note: 'Paid ₹4,500 via UPI and joined' },
    { name: 'Harshvardhan Pai', source: 'Walk-in', stage: 'lost', planId: 'plan-monthly', daysAgo: 9, note: 'Shifted office to Whitefield' },
    { name: 'Tanmayee Joshi', source: 'Instagram', stage: 'trial', planId: 'plan-halfyearly', daysAgo: 3, note: 'Scheduled PT assessment tomorrow 7 AM' },
    { name: 'Omkar Sawant', source: 'Google', stage: 'contacted', planId: 'plan-monthly', daysAgo: 6, note: 'Will visit Saturday morning' },
    { name: 'Dia Chatterjee', source: 'Walk-in', stage: 'new', planId: 'plan-quarterly', daysAgo: 0, note: 'Enquired about morning ladies batch' },
    { name: 'Samarth Hegde', source: 'Referral', stage: 'joined', planId: 'plan-yearly', daysAgo: 7, note: 'Converted on annual plan' },
    { name: 'Payal Mishra', source: 'Google', stage: 'contacted', planId: 'plan-quarterly', daysAgo: 4, note: 'Sent brochure on WhatsApp' },
    { name: 'Keshav Murthy', source: 'Walk-in', stage: 'lost', planId: 'plan-monthly', daysAgo: 12, note: 'Looking for swimming pool facility' },
  ];

  const enquiries: Enquiry[] = leadSeed.map((lead, idx) => ({
    id: `enq-${idx + 1}`,
    name: lead.name,
    phone: makePhone(),
    source: lead.source,
    interestedPlanId: lead.planId,
    stage: lead.stage,
    notes: lead.note,
    createdAt: format(subDays(today, lead.daysAgo), 'yyyy-MM-dd'),
    followUpDate: format(addDays(today, idx % 3), 'yyyy-MM-dd'),
  }));

  return {
    settings: INITIAL_SETTINGS,
    trainers: INITIAL_TRAINERS,
    plans: INITIAL_PLANS,
    members,
    payments,
    expenses,
    attendance,
    enquiries,
  };
}
