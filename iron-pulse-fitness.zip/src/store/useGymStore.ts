import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { format } from 'date-fns';
import type {
  AttendanceRecord,
  BodyStatLog,
  Enquiry,
  Expense,
  GymSettings,
  LeadStage,
  Member,
  MembershipPlan,
  Payment,
  PaymentMode,
  Trainer,
} from '@/src/types';
import { generateSeedData } from '@/src/data/seed';
import { computeExtendedDueDate } from '@/src/lib/feeStatus';
import { generateReceiptNumber } from '@/src/lib/receipt';

interface CollectFeeInput {
  memberId: string;
  planId: string;
  discount: number;
  admissionFee: number;
  ptAddonFee: number;
  mode: PaymentMode;
  date: string;
  note?: string;
}

interface AddMemberInput {
  name: string;
  phone: string;
  email?: string;
  gender: 'M' | 'F' | 'Other';
  planId: string;
  trainerId: string;
  joinDate: string;
  emergencyContact: string;
  notes?: string;
  ptAddon?: boolean;
  collectInitialFee?: boolean;
  paymentMode?: PaymentMode;
}

interface GymState {
  isAuthenticated: boolean;
  settings: GymSettings;
  trainers: Trainer[];
  plans: MembershipPlan[];
  members: Member[];
  payments: Payment[];
  expenses: Expense[];
  attendance: AttendanceRecord[];
  enquiries: Enquiry[];

  // Auth
  loginDemo: () => void;
  logoutDemo: () => void;

  // Members
  addMember: (input: AddMemberInput) => Member;
  updateMember: (id: string, patch: Partial<Member>) => void;
  toggleFreezeMember: (id: string) => void;
  addBodyStat: (memberId: string, stat: Omit<BodyStatLog, 'id'>) => void;

  // Fees / Payments
  collectFee: (input: CollectFeeInput) => Payment;

  // Expenses
  addExpense: (expense: Omit<Expense, 'id'>) => Expense;
  deleteExpense: (id: string) => void;

  // Attendance
  checkInMember: (memberId: string, date?: string) => { created: boolean; record: AttendanceRecord };

  // Plans
  addPlan: (plan: Omit<MembershipPlan, 'id'>) => MembershipPlan;
  updatePlan: (id: string, patch: Partial<MembershipPlan>) => void;
  deletePlan: (id: string) => void;

  // Enquiries
  addEnquiry: (enquiry: Omit<Enquiry, 'id' | 'createdAt'>) => Enquiry;
  updateEnquiryStage: (id: string, stage: LeadStage) => void;
  convertEnquiryToMember: (id: string, trainerId: string, mode: PaymentMode) => Member | null;

  // Settings
  updateSettings: (patch: Partial<GymSettings>) => void;
  toggleDarkMode: () => void;
  resetDemoData: () => void;
}

const initialBundle = generateSeedData();
const AVATAR_PALETTE = ['#121316', '#F26A1B', '#1F9D6B', '#2C5282', '#9C4221', '#285E61'];

export const useGymStore = create<GymState>()(
  persist(
    (set, get) => ({
      isAuthenticated: true, // Demo convenience: accessible immediately, /login also works
      settings: initialBundle.settings,
      trainers: initialBundle.trainers,
      plans: initialBundle.plans,
      members: initialBundle.members,
      payments: initialBundle.payments,
      expenses: initialBundle.expenses,
      attendance: initialBundle.attendance,
      enquiries: initialBundle.enquiries,

      loginDemo: () => set({ isAuthenticated: true }),
      logoutDemo: () => set({ isAuthenticated: false }),

      addMember: (input) => {
        const state = get();
        const plan = state.plans.find((p) => p.id === input.planId) ?? state.plans[0];
        const { periodStart, periodEnd } = computeExtendedDueDate(input.joinDate, plan.durationMonths);
        const newIndex = state.members.length + 1;
        const member: Member = {
          id: `mem-${Date.now()}`,
          code: `IP-${1000 + newIndex}`,
          name: input.name.trim(),
          phone: input.phone.trim(),
          email: input.email?.trim() || undefined,
          gender: input.gender,
          planId: plan.id,
          trainerId: input.trainerId,
          joinDate: input.joinDate,
          nextDueDate: periodEnd,
          status: 'active',
          emergencyContact: input.emergencyContact.trim(),
          notes: input.notes?.trim() ?? '',
          bodyStats: [],
          ptAddon: Boolean(input.ptAddon),
          avatarColor: AVATAR_PALETTE[newIndex % AVATAR_PALETTE.length],
        };

        const nextPayments = [...state.payments];
        if (input.collectInitialFee !== false) {
          const ptPlan = state.plans.find((p) => p.isAddon);
          const ptFee = input.ptAddon && ptPlan ? ptPlan.price : 0;
          const seq = state.payments.length + 1001;
          const payment: Payment = {
            id: `pay-${Date.now()}`,
            receiptNo: generateReceiptNumber(seq, input.joinDate),
            memberId: member.id,
            memberName: member.name,
            planId: plan.id,
            planName: plan.name,
            amount: plan.price,
            discount: 0,
            admissionFee: plan.admissionFee,
            ptAddonFee: ptFee,
            totalPaid: plan.price + plan.admissionFee + ptFee,
            mode: input.paymentMode ?? 'UPI',
            date: input.joinDate,
            periodStart,
            periodEnd,
            note: 'New member admission',
          };
          nextPayments.unshift(payment);
        }

        set({
          members: [member, ...state.members],
          payments: nextPayments,
        });
        return member;
      },

      updateMember: (id, patch) =>
        set((state) => ({
          members: state.members.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        })),

      toggleFreezeMember: (id) =>
        set((state) => ({
          members: state.members.map((m) => {
            if (m.id !== id) return m;
            return {
              ...m,
              status: m.status === 'frozen' ? 'active' : 'frozen',
            };
          }),
        })),

      addBodyStat: (memberId, stat) =>
        set((state) => ({
          members: state.members.map((m) =>
            m.id === memberId
              ? {
                  ...m,
                  bodyStats: [
                    ...m.bodyStats,
                    { ...stat, id: `bs-${Date.now()}` },
                  ].sort((a, b) => (a.date > b.date ? 1 : -1)),
                }
              : m
          ),
        })),

      collectFee: (input) => {
        const state = get();
        const member = state.members.find((m) => m.id === input.memberId);
        const plan = state.plans.find((p) => p.id === input.planId) ?? state.plans[0];
        if (!member) {
          throw new Error('Member not found');
        }

        const { periodStart, periodEnd } = computeExtendedDueDate(
          member.nextDueDate,
          plan.durationMonths
        );

        const totalPaid = Math.max(
          0,
          plan.price + input.admissionFee + input.ptAddonFee - input.discount
        );
        const seq = state.payments.length + 1001;
        const payment: Payment = {
          id: `pay-${Date.now()}`,
          receiptNo: generateReceiptNumber(seq, input.date),
          memberId: member.id,
          memberName: member.name,
          planId: plan.id,
          planName: plan.name,
          amount: plan.price,
          discount: input.discount,
          admissionFee: input.admissionFee,
          ptAddonFee: input.ptAddonFee,
          totalPaid,
          mode: input.mode,
          date: input.date,
          periodStart,
          periodEnd,
          note: input.note?.trim() || 'Membership fee collected',
        };

        set({
          payments: [payment, ...state.payments],
          members: state.members.map((m) =>
            m.id === member.id
              ? {
                  ...m,
                  planId: plan.id,
                  nextDueDate: periodEnd,
                  status: 'active',
                  ptAddon: input.ptAddonFee > 0 ? true : m.ptAddon,
                }
              : m
          ),
        });

        return payment;
      },

      addExpense: (expenseInput) => {
        const expense: Expense = {
          ...expenseInput,
          id: `exp-${Date.now()}`,
        };
        set((state) => ({
          expenses: [expense, ...state.expenses],
        }));
        return expense;
      },

      deleteExpense: (id) =>
        set((state) => ({
          expenses: state.expenses.filter((e) => e.id !== id),
        })),

      checkInMember: (memberId, date) => {
        const state = get();
        const now = new Date();
        const targetDate = date ?? format(now, 'yyyy-MM-dd');
        const existing = state.attendance.find(
          (a) => a.memberId === memberId && a.date === targetDate
        );
        if (existing) {
          return { created: false, record: existing };
        }
        const record: AttendanceRecord = {
          id: `att-${Date.now()}`,
          memberId,
          date: targetDate,
          checkInTime: format(now, 'HH:mm'),
        };
        set({
          attendance: [record, ...state.attendance],
        });
        return { created: true, record };
      },

      addPlan: (planInput) => {
        const plan: MembershipPlan = {
          ...planInput,
          id: `plan-${Date.now()}`,
        };
        set((state) => ({
          plans: [...state.plans, plan],
        }));
        return plan;
      },

      updatePlan: (id, patch) =>
        set((state) => ({
          plans: state.plans.map((p) => (p.id === id ? { ...p, ...patch } : p)),
        })),

      deletePlan: (id) =>
        set((state) => ({
          plans: state.plans.filter((p) => p.id !== id),
        })),

      addEnquiry: (input) => {
        const todayStr = format(new Date(), 'yyyy-MM-dd');
        const enquiry: Enquiry = {
          ...input,
          id: `enq-${Date.now()}`,
          createdAt: todayStr,
        };
        set((state) => ({
          enquiries: [enquiry, ...state.enquiries],
        }));
        return enquiry;
      },

      updateEnquiryStage: (id, stage) =>
        set((state) => ({
          enquiries: state.enquiries.map((e) => (e.id === id ? { ...e, stage } : e)),
        })),

      convertEnquiryToMember: (id, trainerId, mode) => {
        const state = get();
        const enquiry = state.enquiries.find((e) => e.id === id);
        if (!enquiry) return null;

        const todayStr = format(new Date(), 'yyyy-MM-dd');
        const member = state.addMember({
          name: enquiry.name,
          phone: enquiry.phone,
          gender: 'M',
          planId: enquiry.interestedPlanId,
          trainerId,
          joinDate: todayStr,
          emergencyContact: enquiry.phone,
          notes: `Converted from ${enquiry.source} enquiry. ${enquiry.notes}`.trim(),
          collectInitialFee: true,
          paymentMode: mode,
        });

        set((s) => ({
          enquiries: s.enquiries.map((e) => (e.id === id ? { ...e, stage: 'joined' } : e)),
        }));
        return member;
      },

      updateSettings: (patch) =>
        set((state) => ({
          settings: { ...state.settings, ...patch },
        })),

      toggleDarkMode: () =>
        set((state) => ({
          settings: { ...state.settings, darkMode: !state.settings.darkMode },
        })),

      resetDemoData: () => {
        const fresh = generateSeedData();
        set({
          settings: fresh.settings,
          trainers: fresh.trainers,
          plans: fresh.plans,
          members: fresh.members,
          payments: fresh.payments,
          expenses: fresh.expenses,
          attendance: fresh.attendance,
          enquiries: fresh.enquiries,
        });
      },
    }),
    {
      name: 'iron-pulse-fitness-store-v1',
    }
  )
);
