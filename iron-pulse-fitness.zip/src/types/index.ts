export type FeeStatus = 'paid' | 'due-soon' | 'overdue' | 'frozen';
export type MemberStatus = 'active' | 'expiring' | 'expired' | 'frozen';
export type PaymentMode = 'UPI' | 'Cash' | 'Card';

export type ExpenseCategory =
  | 'Rent'
  | 'Electricity'
  | 'Salaries'
  | 'Equipment'
  | 'Maintenance'
  | 'Supplements'
  | 'Marketing'
  | 'Other';

export type LeadStage = 'new' | 'contacted' | 'trial' | 'joined' | 'lost';
export type LeadSource = 'Walk-in' | 'Instagram' | 'Referral' | 'Google';

export interface Trainer {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  avatarColor: string;
}

export interface MembershipPlan {
  id: string;
  name: string;
  durationMonths: number;
  price: number;
  admissionFee: number;
  isAddon?: boolean;
  description: string;
  active: boolean;
}

export interface BodyStatLog {
  id: string;
  date: string; // YYYY-MM-DD
  weightKg: number;
  bodyFatPct?: number;
  waistIn?: number;
}

export interface Member {
  id: string;
  code: string;
  name: string;
  phone: string;
  email?: string;
  gender: 'M' | 'F' | 'Other';
  planId: string;
  trainerId: string;
  joinDate: string; // YYYY-MM-DD
  nextDueDate: string; // YYYY-MM-DD
  status: MemberStatus;
  emergencyContact: string;
  notes: string;
  bodyStats: BodyStatLog[];
  ptAddon: boolean;
  avatarColor: string;
}

export interface Payment {
  id: string;
  receiptNo: string;
  memberId: string;
  memberName: string;
  planId: string;
  planName: string;
  amount: number;
  discount: number;
  admissionFee: number;
  ptAddonFee: number;
  totalPaid: number;
  mode: PaymentMode;
  date: string; // YYYY-MM-DD
  periodStart: string;
  periodEnd: string;
  note?: string;
}

export interface Expense {
  id: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  date: string; // YYYY-MM-DD
  mode: PaymentMode;
  note: string;
  recurring: boolean;
}

export interface AttendanceRecord {
  id: string;
  memberId: string;
  date: string; // YYYY-MM-DD
  checkInTime: string; // HH:mm
}

export interface Enquiry {
  id: string;
  name: string;
  phone: string;
  source: LeadSource;
  interestedPlanId: string;
  stage: LeadStage;
  notes: string;
  createdAt: string; // YYYY-MM-DD
  followUpDate: string; // YYYY-MM-DD
}

export interface GymSettings {
  gymName: string;
  tagline: string;
  address: string;
  phone: string;
  gstin: string;
  ownerName: string;
  reminderDays: number;
  whatsappTemplate: string;
  darkMode: boolean;
}
