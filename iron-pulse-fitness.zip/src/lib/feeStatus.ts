import { addMonths, differenceInCalendarDays, format, parseISO, startOfDay } from 'date-fns';
import type { FeeStatus, Member } from '@/src/types';

export interface FeeStatusInfo {
  status: FeeStatus;
  daysToDue: number;
  label: string;
  shortLabel: string;
  colorHex: string;
}

export function getDaysToDue(nextDueDate: string, referenceDate: Date = new Date()): number {
  const due = startOfDay(parseISO(nextDueDate));
  const today = startOfDay(referenceDate);
  return differenceInCalendarDays(due, today);
}

export function getFeeStatus(
  member: Pick<Member, 'status' | 'nextDueDate'>,
  reminderDays: number = 7,
  referenceDate: Date = new Date()
): FeeStatusInfo {
  const daysToDue = getDaysToDue(member.nextDueDate, referenceDate);

  if (member.status === 'frozen') {
    return {
      status: 'frozen',
      daysToDue,
      label: 'Frozen',
      shortLabel: 'Frozen',
      colorHex: '#66635B',
    };
  }

  if (daysToDue < 0) {
    const overdueDays = Math.abs(daysToDue);
    return {
      status: 'overdue',
      daysToDue,
      label: `Overdue by ${overdueDays} ${overdueDays === 1 ? 'day' : 'days'}`,
      shortLabel: `${overdueDays}d overdue`,
      colorHex: '#D6403A',
    };
  }

  if (daysToDue <= reminderDays) {
    return {
      status: 'due-soon',
      daysToDue,
      label: daysToDue === 0 ? 'Due today' : `Due in ${daysToDue} ${daysToDue === 1 ? 'day' : 'days'}`,
      shortLabel: daysToDue === 0 ? 'Due today' : `In ${daysToDue}d`,
      colorHex: '#E8B30C',
    };
  }

  return {
    status: 'paid',
    daysToDue,
    label: 'Paid',
    shortLabel: 'Paid',
    colorHex: '#1F9D6B',
  };
}

export function computeExtendedDueDate(
  currentNextDueDate: string,
  durationMonths: number,
  referenceDate: Date = new Date()
): { periodStart: string; periodEnd: string } {
  const today = startOfDay(referenceDate);
  const currentDue = startOfDay(parseISO(currentNextDueDate));
  const baseDate = currentDue < today ? today : currentDue;
  const endDate = addMonths(baseDate, durationMonths);

  return {
    periodStart: format(baseDate, 'yyyy-MM-dd'),
    periodEnd: format(endDate, 'yyyy-MM-dd'),
  };
}

export function isExpiringInDays(
  member: Pick<Member, 'status' | 'nextDueDate'>,
  days: number = 7,
  referenceDate: Date = new Date()
): boolean {
  if (member.status === 'frozen') return false;
  const diff = getDaysToDue(member.nextDueDate, referenceDate);
  return diff >= 0 && diff <= days;
}
