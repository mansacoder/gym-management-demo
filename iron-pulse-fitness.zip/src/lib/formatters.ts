import { format, parseISO } from 'date-fns';

const inrFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

const numberFormatter = new Intl.NumberFormat('en-IN');

export function formatINR(amount: number): string {
  return inrFormatter.format(Math.round(amount));
}

export function formatNumber(value: number): string {
  return numberFormatter.format(Math.round(value));
}

export function formatCompactINR(amount: number): string {
  const abs = Math.abs(amount);
  const sign = amount < 0 ? '-' : '';
  if (abs >= 10000000) {
    return `${sign}₹${(abs / 10000000).toFixed(2)}Cr`;
  }
  if (abs >= 100000) {
    return `${sign}₹${(abs / 100000).toFixed(2)}L`;
  }
  if (abs >= 1000) {
    return `${sign}₹${(abs / 1000).toFixed(1)}K`;
  }
  return formatINR(amount);
}

export function formatDisplayDate(isoDate: string): string {
  try {
    return format(parseISO(isoDate), 'dd MMM yyyy');
  } catch {
    return isoDate;
  }
}

export function formatShortDate(isoDate: string): string {
  try {
    return format(parseISO(isoDate), 'dd MMM');
  } catch {
    return isoDate;
  }
}

export function formatPhoneDisplay(phone: string): string {
  const digits = phone.replace(/\D/g, '').slice(-10);
  if (digits.length === 10) {
    return `+91 ${digits.slice(0, 5)} ${digits.slice(5)}`;
  }
  return phone;
}

export function buildTelUrl(phone: string): string {
  const digits = phone.replace(/\D/g, '').slice(-10);
  return `tel:+91${digits}`;
}

export function buildWhatsAppUrl(phone: string, message: string): string {
  const digits = phone.replace(/\D/g, '').slice(-10);
  const encoded = encodeURIComponent(message);
  return `https://wa.me/91${digits}?text=${encoded}`;
}

export function fillWhatsAppTemplate(
  template: string,
  params: {
    name: string;
    amount: number;
    date: string;
    gymName: string;
  }
): string {
  return template
    .replace(/\{name\}/g, params.name.split(' ')[0])
    .replace(/\{fullName\}/g, params.name)
    .replace(/\{amount\}/g, numberFormatter.format(Math.round(params.amount)))
    .replace(/\{date\}/g, formatDisplayDate(params.date))
    .replace(/\{gymName\}/g, params.gymName);
}

export function downloadCsv(filename: string, headers: string[], rows: (string | number)[][]): void {
  const escapeCell = (cell: string | number): string => {
    const str = String(cell);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const csvContent = [
    headers.map(escapeCell).join(','),
    ...rows.map((r) => r.map(escapeCell).join(',')),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
