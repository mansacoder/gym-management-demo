import { lazy, Suspense, useEffect } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Toaster } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { AppShell } from '@/src/app/AppShell';
import { ErrorBoundary } from '@/src/components/common/ErrorBoundary';
import { Skeleton } from '@/src/components/ui/input';
import { SplashScreen } from '@/src/components/pwa/SplashScreen';

const LoginPage = lazy(() => import('@/src/features/auth/LoginPage'));
const DashboardPage = lazy(() => import('@/src/features/dashboard/DashboardPage'));
const MembersPage = lazy(() => import('@/src/features/members/MembersPage'));
const MemberProfilePage = lazy(() => import('@/src/features/members/MemberProfilePage'));
const FeesPage = lazy(() => import('@/src/features/fees/FeesPage'));
const CollectFeePage = lazy(() => import('@/src/features/fees/CollectFeePage'));
const ExpensesPage = lazy(() => import('@/src/features/expenses/ExpensesPage'));
const AttendancePage = lazy(() => import('@/src/features/attendance/AttendancePage'));
const PlansPage = lazy(() => import('@/src/features/plans/PlansPage'));
const EnquiriesPage = lazy(() => import('@/src/features/enquiries/EnquiriesPage'));
const ReportsPage = lazy(() => import('@/src/features/reports/ReportsPage'));
const SettingsPage = lazy(() => import('@/src/features/settings/SettingsPage'));

function PageSkeleton() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
        <Skeleton className="h-28" />
      </div>
      <Skeleton className="h-72" />
    </div>
  );
}

function ProtectedShell() {
  const isAuthenticated = useGymStore((s) => s.isAuthenticated);
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <AppShell />;
}

export default function App() {
  const darkMode = useGymStore((s) => s.settings.darkMode);

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <ErrorBoundary>
      <BrowserRouter>
        <SplashScreen />
        <Toaster
          position="top-center"
          richColors
          theme={darkMode ? 'dark' : 'light'}
        />
        <Suspense
          fallback={
            <div className="p-6">
              <PageSkeleton />
            </div>
          }
        >
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route element={<ProtectedShell />}>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<DashboardPage />} />
              <Route path="/members" element={<MembersPage />} />
              <Route path="/members/:id" element={<MemberProfilePage />} />
              <Route path="/fees" element={<FeesPage />} />
              <Route path="/fees/collect" element={<CollectFeePage />} />
              <Route path="/expenses" element={<ExpensesPage />} />
              <Route path="/attendance" element={<AttendancePage />} />
              <Route path="/plans" element={<PlansPage />} />
              <Route path="/enquiries" element={<EnquiriesPage />} />
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/settings" element={<SettingsPage />} />
            </Route>
            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
