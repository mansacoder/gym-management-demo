import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { toast } from 'sonner';
import type { Member } from '@/src/types';
import { useGymStore } from '@/src/store/useGymStore';
import { formatINR } from '@/src/lib/formatters';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { Button } from '@/src/components/ui/button';
import { Input, Select, Textarea } from '@/src/components/ui/input';

const memberSchema = z.object({
  name: z.string().min(2, 'Enter member full name'),
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Enter valid 10-digit Indian mobile number'),
  email: z.string().email('Enter valid email').optional().or(z.literal('')),
  gender: z.enum(['M', 'F', 'Other']),
  planId: z.string().min(1, 'Select a plan'),
  trainerId: z.string().min(1, 'Select a trainer'),
  joinDate: z.string().min(1, 'Select start date'),
  emergencyContact: z.string().regex(/^[6-9]\d{9}$/, 'Enter valid 10-digit emergency contact'),
  ptAddon: z.boolean(),
  notes: z.string().optional(),
  collectInitialFee: z.boolean(),
  paymentMode: z.enum(['UPI', 'Cash', 'Card']),
});

type MemberFormValues = z.infer<typeof memberSchema>;

interface MemberFormSheetProps {
  open: boolean;
  onClose: () => void;
  editingMember?: Member | null;
  onSaved?: (member: Member) => void;
}

export function MemberFormSheet({
  open,
  onClose,
  editingMember,
  onSaved,
}: MemberFormSheetProps) {
  const plans = useGymStore((s) => s.plans);
  const trainers = useGymStore((s) => s.trainers);
  const addMember = useGymStore((s) => s.addMember);
  const updateMember = useGymStore((s) => s.updateMember);

  const corePlans = plans.filter((p) => !p.isAddon && p.active);
  const ptPlan = plans.find((p) => p.isAddon);

  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<MemberFormValues>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      name: '',
      phone: '',
      email: '',
      gender: 'M',
      planId: corePlans[0]?.id ?? 'plan-monthly',
      trainerId: trainers[0]?.id ?? 'trn-1',
      joinDate: format(new Date(), 'yyyy-MM-dd'),
      emergencyContact: '',
      ptAddon: false,
      notes: '',
      collectInitialFee: true,
      paymentMode: 'UPI',
    },
  });

  useEffect(() => {
    if (!open) return;
    if (editingMember) {
      reset({
        name: editingMember.name,
        phone: editingMember.phone,
        email: editingMember.email ?? '',
        gender: editingMember.gender,
        planId: editingMember.planId,
        trainerId: editingMember.trainerId,
        joinDate: editingMember.joinDate,
        emergencyContact: editingMember.emergencyContact,
        ptAddon: editingMember.ptAddon,
        notes: editingMember.notes,
        collectInitialFee: false,
        paymentMode: 'UPI',
      });
    } else {
      reset({
        name: '',
        phone: '',
        email: '',
        gender: 'M',
        planId: corePlans[0]?.id ?? 'plan-monthly',
        trainerId: trainers[0]?.id ?? 'trn-1',
        joinDate: format(new Date(), 'yyyy-MM-dd'),
        emergencyContact: '',
        ptAddon: false,
        notes: '',
        collectInitialFee: true,
        paymentMode: 'UPI',
      });
    }
  }, [open, editingMember, reset]);

  const selectedPlanId = watch('planId');
  const ptAddonChecked = watch('ptAddon');
  const collectFee = watch('collectInitialFee');
  const selectedPlan = corePlans.find((p) => p.id === selectedPlanId) ?? corePlans[0];
  const initialTotal =
    (selectedPlan?.price ?? 0) +
    (selectedPlan?.admissionFee ?? 0) +
    (ptAddonChecked && ptPlan ? ptPlan.price : 0);

  const onSubmit = (values: MemberFormValues) => {
    if (editingMember) {
      updateMember(editingMember.id, {
        name: values.name,
        phone: values.phone,
        email: values.email || undefined,
        gender: values.gender,
        planId: values.planId,
        trainerId: values.trainerId,
        joinDate: values.joinDate,
        emergencyContact: values.emergencyContact,
        ptAddon: values.ptAddon,
        notes: values.notes ?? '',
      });
      toast.success(`${values.name} updated`);
      onClose();
      return;
    }

    const created = addMember(values);
    toast.success(`${created.name} added to IRON PULSE`);
    onSaved?.(created);
    onClose();
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={editingMember ? 'Edit Member' : 'Add New Member'}
      subtitle={editingMember ? editingMember.code : 'Instant admission & fee schedule'}
      footer={
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="member-form" className="flex-1">
            {editingMember ? 'Save Changes' : 'Add Member'}
          </Button>
        </div>
      }
    >
      <form id="member-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
            Full Name
          </label>
          <Input placeholder="e.g. Rohan Verma" {...register('name')} />
          {errors.name && <p className="mt-1 text-xs text-[#D6403A]">{errors.name.message}</p>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
              Mobile Number
            </label>
            <Input placeholder="9876543210" maxLength={10} {...register('phone')} />
            {errors.phone && (
              <p className="mt-1 text-xs text-[#D6403A]">{errors.phone.message}</p>
            )}
          </div>
          <div>
            <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
              Gender
            </label>
            <Select {...register('gender')}>
              <option value="M">Male</option>
              <option value="F">Female</option>
              <option value="Other">Other</option>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
              Membership Plan
            </label>
            <Select {...register('planId')}>
              {corePlans.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({formatINR(p.price)})
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
              Start Date
            </label>
            <Input type="date" {...register('joinDate')} />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
              Assigned Trainer
            </label>
            <Select {...register('trainerId')}>
              {trainers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
              Emergency Contact
            </label>
            <Input placeholder="98XXXXXXXX" maxLength={10} {...register('emergencyContact')} />
            {errors.emergencyContact && (
              <p className="mt-1 text-xs text-[#D6403A]">{errors.emergencyContact.message}</p>
            )}
          </div>
        </div>

        {ptPlan && (
          <label className="flex items-center justify-between rounded-xl border border-[var(--border)] p-3 cursor-pointer">
            <div>
              <p className="text-sm font-semibold text-[var(--text)]">
                Personal Training Add-on
              </p>
              <p className="text-xs text-[var(--text-muted)]">
                +{formatINR(ptPlan.price)}/month coached sessions
              </p>
            </div>
            <input
              type="checkbox"
              className="h-5 w-5 accent-[#F26A1B]"
              {...register('ptAddon')}
            />
          </label>
        )}

        {!editingMember && (
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--bg)] p-3.5 space-y-3">
            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <p className="text-sm font-semibold text-[var(--text)]">
                  Collect initial fee now
                </p>
                <p className="text-xs text-[var(--text-muted)] tabular-nums">
                  Total payable: {formatINR(initialTotal)} (incl. admission)
                </p>
              </div>
              <input
                type="checkbox"
                className="h-5 w-5 accent-[#F26A1B]"
                {...register('collectInitialFee')}
              />
            </label>
            {collectFee && (
              <div>
                <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
                  Payment Mode
                </label>
                <Select {...register('paymentMode')}>
                  <option value="UPI">UPI</option>
                  <option value="Cash">Cash</option>
                  <option value="Card">Card</option>
                </Select>
              </div>
            )}
          </div>
        )}

        <div>
          <label className="block text-xs font-semibold text-[var(--text)] mb-1.5">
            Goal / Batch Notes
          </label>
          <Textarea placeholder="e.g. Morning 7 AM batch, fat loss goal" {...register('notes')} />
        </div>
      </form>
    </BottomSheet>
  );
}
