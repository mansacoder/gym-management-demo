import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ChevronRight, Dumbbell, Plus, Search, Snowflake, Users } from 'lucide-react';
import { useGymStore } from '@/src/store/useGymStore';
import { formatDisplayDate, formatINR, formatPhoneDisplay } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Avatar } from '@/src/components/common/Avatar';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { EmptyState } from '@/src/components/common/EmptyState';
import { Button } from '@/src/components/ui/button';
import { Select } from '@/src/components/ui/input';
import { MemberFormSheet } from '@/src/features/members/MemberFormSheet';

type FilterChip = 'all' | 'active' | 'pt' | 'frozen';
type SortKey = 'newest' | 'oldest' | 'name-asc';

export default function MembersPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const rawFilter = searchParams.get('filter');
  const initialFilter: FilterChip =
    rawFilter === 'active' || rawFilter === 'pt' || rawFilter === 'frozen'
      ? rawFilter
      : 'all';

  const members = useGymStore((s) => s.members);
  const plans = useGymStore((s) => s.plans);
  const trainers = useGymStore((s) => s.trainers);

  const [query, setQuery] = useState('');
  const [chip, setChip] = useState<FilterChip>(initialFilter);
  const [planFilter, setPlanFilter] = useState('all');
  const [trainerFilter, setTrainerFilter] = useState('all');
  const [sortBy, setSortBy] = useState<SortKey>('newest');
  const [addOpen, setAddOpen] = useState(false);

  const enriched = useMemo(() => {
    return members.map((member) => {
      const plan = plans.find((p) => p.id === member.planId);
      const trainer = trainers.find((t) => t.id === member.trainerId);
      return { member, plan, trainer };
    });
  }, [members, plans, trainers]);

  const counts = useMemo(() => {
    return {
      all: enriched.length,
      active: enriched.filter((e) => e.member.status !== 'frozen').length,
      pt: enriched.filter((e) => e.member.ptAddon).length,
      frozen: enriched.filter((e) => e.member.status === 'frozen').length,
    };
  }, [enriched]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return enriched
      .filter((item) => {
        if (chip === 'active' && item.member.status === 'frozen') return false;
        if (chip === 'pt' && !item.member.ptAddon) return false;
        if (chip === 'frozen' && item.member.status !== 'frozen') return false;
        if (planFilter !== 'all' && item.member.planId !== planFilter) return false;
        if (trainerFilter !== 'all' && item.member.trainerId !== trainerFilter) return false;
        if (q) {
          const hit =
            item.member.name.toLowerCase().includes(q) ||
            item.member.phone.includes(q) ||
            item.member.code.toLowerCase().includes(q);
          if (!hit) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'name-asc') return a.member.name.localeCompare(b.member.name);
        if (sortBy === 'oldest') return a.member.joinDate.localeCompare(b.member.joinDate);
        return b.member.joinDate.localeCompare(a.member.joinDate);
      });
  }, [enriched, chip, planFilter, trainerFilter, query, sortBy]);

  const handleChipChange = (next: FilterChip) => {
    setChip(next);
    if (next === 'all') {
      searchParams.delete('filter');
    } else {
      searchParams.set('filter', next);
    }
    setSearchParams(searchParams, { replace: true });
  };

  const CHIPS: Array<{ id: FilterChip; label: string; count: number }> = [
    { id: 'all', label: 'All Members', count: counts.all },
    { id: 'active', label: 'Active', count: counts.active },
    { id: 'pt', label: 'Personal Training', count: counts.pt },
    { id: 'frozen', label: 'Frozen', count: counts.frozen },
  ];

  return (
    <div className="space-y-5">
      {/* Top Roster Overview + Add CTA */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[var(--text-muted)] tabular-nums">
          <span>
            <strong className="text-sm font-bold text-[var(--text)]">{counts.all}</strong> total members
          </span>
          <span aria-hidden="true">·</span>
          <span>
            <strong className="text-sm font-bold text-[var(--text)]">{counts.active}</strong> active
          </span>
          <span aria-hidden="true">·</span>
          <span>
            <strong className="text-sm font-bold text-[#F26A1B]">{counts.pt}</strong> PT coached
          </span>
        </div>
        <Button type="button" onClick={() => setAddOpen(true)} className="w-full sm:w-auto">
          <Plus className="h-4 w-4" />
          <span>Add Member</span>
        </Button>
      </div>

      {/* Search + Filters */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 space-y-3.5">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5">
          <div className="relative md:col-span-5">
            <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-[var(--text-muted)]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search name, mobile, or IP code..."
              className="h-11 w-full rounded-xl border border-[var(--border)] bg-[var(--bg)] pl-10 pr-3.5 text-sm text-[var(--text)] placeholder:text-[var(--text-muted)]/70 focus:outline-none focus:ring-2 focus:ring-[#F26A1B]"
            />
          </div>
          <div className="grid grid-cols-3 gap-2 md:col-span-7">
            <Select
              value={planFilter}
              onChange={(e) => setPlanFilter(e.target.value)}
              aria-label="Filter by plan"
            >
              <option value="all">All Plans</option>
              {plans
                .filter((p) => !p.isAddon)
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
            </Select>
            <Select
              value={trainerFilter}
              onChange={(e) => setTrainerFilter(e.target.value)}
              aria-label="Filter by trainer"
            >
              <option value="all">All Trainers</option>
              {trainers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name.split(' ')[0]}
                </option>
              ))}
            </Select>
            <Select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortKey)}
              aria-label="Sort members"
            >
              <option value="newest">Newest Joined</option>
              <option value="oldest">Oldest Joined</option>
              <option value="name-asc">Name A–Z</option>
            </Select>
          </div>
        </div>

        {/* Interactive Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
          {CHIPS.map((c) => {
            const active = chip === c.id;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => handleChipChange(c.id)}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer min-h-[38px]',
                  active
                    ? 'bg-[#121316] text-white dark:bg-[#F26A1B] dark:text-white'
                    : 'bg-[var(--bg)] text-[var(--text-muted)] hover:text-[var(--text)]'
                )}
              >
                <span>{c.label}</span>
                <span className="tabular-nums opacity-75">{c.count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Empty state */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No matching members"
          description="Try clearing your search or switching filter tabs."
          actionLabel="Reset Filters"
          onAction={() => {
            setQuery('');
            setPlanFilter('all');
            setTrainerFilter('all');
            handleChipChange('all');
          }}
        />
      ) : (
        <>
          {/* Mobile Native Cards */}
          <div className="space-y-3 md:hidden">
            {filtered.map(({ member, plan, trainer }) => (
              <div
                key={member.id}
                onClick={() => navigate(`/members/${member.id}`)}
                className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 active:scale-[0.99] transition-all hover:border-[#F26A1B]/40 cursor-pointer"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={member.name} color={member.avatarColor} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-bold text-[var(--text)] truncate">
                          {member.name}
                        </p>
                        {member.status === 'frozen' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[var(--text-muted)]">
                            <Snowflake className="h-3 w-3" /> Frozen
                          </span>
                        )}
                      </div>
                      <p className="mt-0.5 text-xs text-[var(--text-muted)] tabular-nums truncate">
                        {member.code} · {formatPhoneDisplay(member.phone)}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm font-bold text-[var(--text)] tabular-nums shrink-0">
                    {formatINR(plan?.price ?? 1500)}
                  </span>
                </div>

                <div className="mt-3 flex items-center justify-between gap-2 border-t border-[var(--border)] pt-3">
                  <div className="min-w-0 text-xs text-[var(--text-muted)]">
                    <p className="font-medium text-[var(--text)] truncate">
                      {plan?.name ?? 'Monthly'}
                      {member.ptAddon ? ' + PT' : ''} · {trainer?.name.split(' ')[0]}
                    </p>
                    <p className="mt-0.5 tabular-nums">
                      Joined {formatDisplayDate(member.joinDate)}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <CallButton phone={member.phone} name={member.name} />
                    <WhatsAppButton
                      phone={member.phone}
                      name={member.name}
                      amount={plan?.price ?? 1500}
                      dueDate={member.nextDueDate}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Desktop Refined Directory Table */}
          <div className="hidden md:block overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface)]">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[var(--border)] bg-[var(--bg)] text-xs font-semibold text-[var(--text-muted)]">
                    <th className="py-3.5 pl-5 pr-3">Member</th>
                    <th className="py-3.5 px-3">Plan &amp; Coach</th>
                    <th className="py-3.5 px-3">Joining Date</th>
                    <th className="py-3.5 px-3 text-right">Plan Fee</th>
                    <th className="py-3.5 pl-3 pr-5 text-right">Contact</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border)]">
                  {filtered.map(({ member, plan, trainer }) => (
                    <tr
                      key={member.id}
                      onClick={() => navigate(`/members/${member.id}`)}
                      className="group hover:bg-[var(--bg)]/75 transition-colors cursor-pointer"
                    >
                      <td className="py-3.5 pl-5 pr-3">
                        <div className="flex items-center gap-3.5">
                          <Avatar name={member.name} color={member.avatarColor} size="sm" />
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-[var(--text)] truncate group-hover:text-[#F26A1B] transition-colors">
                                {member.name}
                              </p>
                              {member.status === 'frozen' && (
                                <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[var(--text-muted)]">
                                  <Snowflake className="h-3 w-3" /> Frozen
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-[var(--text-muted)] tabular-nums">
                              {member.code} · {formatPhoneDisplay(member.phone)}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-3">
                        <div className="flex items-center gap-1.5 font-medium text-[var(--text)]">
                          <span>{plan?.name ?? 'Monthly'}</span>
                          {member.ptAddon && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#F26A1B]">
                              <Dumbbell className="h-3 w-3" /> PT
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[var(--text-muted)]">
                          Coach: {trainer?.name ?? 'Unassigned'}
                        </p>
                      </td>
                      <td className="py-3.5 px-3 text-xs font-medium text-[var(--text)] tabular-nums whitespace-nowrap">
                        {formatDisplayDate(member.joinDate)}
                      </td>
                      <td className="py-3.5 px-3 text-right font-semibold text-[var(--text)] tabular-nums">
                        {formatINR(plan?.price ?? 1500)}
                      </td>
                      <td
                        className="py-3.5 pl-3 pr-5"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-end gap-1.5">
                          <CallButton phone={member.phone} name={member.name} />
                          <WhatsAppButton
                            phone={member.phone}
                            name={member.name}
                            amount={plan?.price ?? 1500}
                            dueDate={member.nextDueDate}
                          />
                          <button
                            type="button"
                            onClick={() => navigate(`/members/${member.id}`)}
                            aria-label={`Open ${member.name} profile`}
                            className="flex h-9 w-9 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--surface-muted)] hover:text-[var(--text)] transition-colors cursor-pointer"
                          >
                            <ChevronRight className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      <MemberFormSheet open={addOpen} onClose={() => setAddOpen(false)} />
    </div>
  );
}
