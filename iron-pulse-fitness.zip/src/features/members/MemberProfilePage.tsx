import { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { eachDayOfInterval, format, subDays } from 'date-fns';
import { ArrowLeft, CalendarCheck, CreditCard, Edit3, Plus, RefreshCw, Snowflake } from 'lucide-react';
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { toast } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { getFeeStatus } from '@/src/lib/feeStatus';
import { formatDisplayDate, formatINR, formatPhoneDisplay, formatShortDate } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Avatar } from '@/src/components/common/Avatar';
import { StatusBadge } from '@/src/components/common/StatusBadge';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { ReceiptModal } from '@/src/components/common/ReceiptModal';
import { Button } from '@/src/components/ui/button';
import { Input } from '@/src/components/ui/input';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { MemberFormSheet } from '@/src/features/members/MemberFormSheet';
import type { Payment } from '@/src/types';

export default function MemberProfilePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const member = useGymStore((s) => s.members.find((m) => m.id === id));
  const plans = useGymStore((s) => s.plans);
  const trainers = useGymStore((s) => s.trainers);
  const payments = useGymStore((s) => s.payments);
  const attendance = useGymStore((s) => s.attendance);
  const settings = useGymStore((s) => s.settings);
  const toggleFreezeMember = useGymStore((s) => s.toggleFreezeMember);
  const checkInMember = useGymStore((s) => s.checkInMember);
  const addBodyStat = useGymStore((s) => s.addBodyStat);

  const [editOpen, setEditOpen] = useState(false);
  const [statOpen, setStatOpen] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<Payment | null>(null);
  const [weightKg, setWeightKg] = useState('72.5');
  const [bodyFatPct, setBodyFatPct] = useState('18.2');
  const [waistIn, setWaistIn] = useState('32.0');

  const memberPayments = useMemo(
    () => payments.filter((p) => p.memberId === id),
    [payments, id]
  );

  const attendanceSet = useMemo(() => {
    const set = new Set<string>();
    attendance.forEach((a) => {
      if (a.memberId === id) set.add(a.date);
    });
    return set;
  }, [attendance, id]);

  const last30Days = useMemo(() => {
    const today = new Date();
    return eachDayOfInterval({ start: subDays(today, 29), end: today });
  }, []);

  if (!member) {
    return (
      <div className="space-y-4">
        <Button type="button" variant="outline" onClick={() => navigate('/members')}>
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Members</span>
        </Button>
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-8 text-center">
          <p className="text-base font-bold">Member not found</p>
        </div>
      </div>
    );
  }

  const plan = plans.find((p) => p.id === member.planId);
  const trainer = trainers.find((t) => t.id === member.trainerId);
  const fee = getFeeStatus(member, settings.reminderDays);
  const thirtyDayCount = last30Days.filter((d) =>
    attendanceSet.has(format(d, 'yyyy-MM-dd'))
  ).length;

  const handleLogStat = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(weightKg);
    if (Number.isNaN(w) || w <= 20) {
      toast.error('Enter a valid weight in kg');
      return;
    }
    addBodyStat(member.id, {
      date: format(new Date(), 'yyyy-MM-dd'),
      weightKg: w,
      bodyFatPct: parseFloat(bodyFatPct) || undefined,
      waistIn: parseFloat(waistIn) || undefined,
    });
    toast.success('Body measurement logged');
    setStatOpen(false);
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3">
        <Button type="button" variant="outline" size="sm" onClick={() => navigate('/members')}>
          <ArrowLeft className="h-4 w-4" />
          <span>All Members</span>
        </Button>
        <Button type="button" variant="outline" size="sm" onClick={() => setEditOpen(true)}>
          <Edit3 className="h-4 w-4" />
          <span>Edit Profile</span>
        </Button>
      </div>

      {/* Hero Profile Card */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4 min-w-0">
            <Avatar name={member.name} color={member.avatarColor} size="lg" />
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-bold tracking-tight text-[var(--text)] truncate">
                  {member.name}
                </h2>
                <StatusBadge status={fee.status} label={fee.label} />
              </div>
              <p className="mt-1 text-xs text-[var(--text-muted)] tabular-nums">
                {member.code} · {formatPhoneDisplay(member.phone)} · Joined{' '}
                {formatDisplayDate(member.joinDate)}
              </p>
              <p className="mt-0.5 text-xs text-[var(--text-muted)]">
                Plan: <strong className="text-[var(--text)]">{plan?.name}</strong> · Coach:{' '}
                <strong className="text-[var(--text)]">{trainer?.name}</strong>
                {member.ptAddon ? ' · PT Add-on' : ''}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <CallButton phone={member.phone} name={member.name} showLabel size="md" />
            <WhatsAppButton
              phone={member.phone}
              name={member.name}
              amount={plan?.price ?? 1500}
              dueDate={member.nextDueDate}
              showLabel
              size="md"
            />
          </div>
        </div>

        {/* Action Strip */}
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-2.5 border-t border-[var(--border)] pt-4">
          <Button
            type="button"
            onClick={() => navigate(`/fees/collect?memberId=${member.id}`)}
          >
            <CreditCard className="h-4 w-4" />
            <span>Collect Fee</span>
          </Button>
          <Button
            type="button"
            variant="ink"
            onClick={() => navigate(`/fees/collect?memberId=${member.id}&renew=1`)}
          >
            <RefreshCw className="h-4 w-4" />
            <span>Renew Plan</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              const res = checkInMember(member.id);
              toast.success(
                res.created
                  ? `${member.name} checked in at ${res.record.checkInTime}`
                  : `${member.name} already checked in today`
              );
            }}
          >
            <CalendarCheck className="h-4 w-4" />
            <span>Check In</span>
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => {
              toggleFreezeMember(member.id);
              toast.success(
                member.status === 'frozen'
                  ? `${member.name} membership resumed`
                  : `${member.name} membership frozen`
              );
            }}
          >
            <Snowflake className="h-4 w-4" />
            <span>{member.status === 'frozen' ? 'Unfreeze' : 'Freeze'}</span>
          </Button>
        </div>
      </div>

      {/* Info + Attendance + Body Stats Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Details & Notes */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
          <h3 className="text-sm font-bold text-[var(--text)]">Membership Details</h3>
          <dl className="space-y-3 text-xs">
            <div className="flex justify-between">
              <dt className="text-[var(--text-muted)]">Next Fee Due</dt>
              <dd className="font-semibold text-[var(--text)] tabular-nums">
                {formatDisplayDate(member.nextDueDate)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[var(--text-muted)]">Monthly / Plan Fee</dt>
              <dd className="font-semibold text-[var(--text)] tabular-nums">
                {formatINR(plan?.price ?? 1500)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[var(--text-muted)]">Emergency Contact</dt>
              <dd className="font-semibold text-[var(--text)] tabular-nums">
                {formatPhoneDisplay(member.emergencyContact)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[var(--text-muted)]">Assigned Trainer</dt>
              <dd className="font-semibold text-[var(--text)]">{trainer?.name}</dd>
            </div>
          </dl>
          <div className="border-t border-[var(--border)] pt-3">
            <p className="text-xs font-semibold text-[var(--text)]">Coach Notes</p>
            <p className="mt-1 text-xs text-[var(--text-muted)] leading-relaxed">
              {member.notes || 'No notes added yet.'}
            </p>
          </div>
        </div>

        {/* 30-Day Attendance Calendar */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-[var(--text)]">30-Day Attendance</h3>
            <span className="text-xs font-semibold text-[#1F9D6B] tabular-nums">
              {thirtyDayCount} / 30 days
            </span>
          </div>
          <div className="mt-4 grid grid-cols-6 gap-2">
            {last30Days.map((day) => {
              const iso = format(day, 'yyyy-MM-dd');
              const present = attendanceSet.has(iso);
              return (
                <div
                  key={iso}
                  title={`${formatDisplayDate(iso)}: ${present ? 'Present' : 'Absent'}`}
                  className={cn(
                    'flex flex-col items-center justify-center rounded-xl py-2 text-[11px] font-semibold tabular-nums border',
                    present
                      ? 'bg-[#1F9D6B]/14 border-[#1F9D6B]/30 text-[#167952] dark:text-[#3CD296]'
                      : 'bg-[var(--bg)] border-[var(--border)] text-[var(--text-muted)]'
                  )}
                >
                  <span>{format(day, 'd')}</span>
                  <span className="text-[9px] opacity-75">{format(day, 'MMM')}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Body Stats Log & Chart */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-[var(--text)]">Body Stats (Weight kg)</h3>
              <Button type="button" size="sm" variant="outline" onClick={() => setStatOpen(true)}>
                <Plus className="h-3.5 w-3.5" />
                <span>Log</span>
              </Button>
            </div>
            {member.bodyStats.length > 0 ? (
              <div className="mt-3 h-36 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={member.bodyStats}>
                    <XAxis
                      dataKey="date"
                      tickFormatter={(v: string) => formatShortDate(v)}
                      tick={{ fontSize: 10 }}
                      stroke="#8A877E"
                    />
                    <YAxis domain={['auto', 'auto']} tick={{ fontSize: 10 }} width={32} stroke="#8A877E" />
                    <Tooltip
                      formatter={(value) => [`${Number(value ?? 0)} kg`, 'Weight']}
                      labelFormatter={(label) => formatDisplayDate(String(label ?? ''))}
                    />
                    <Line
                      type="monotone"
                      dataKey="weightKg"
                      stroke="#F26A1B"
                      strokeWidth={2.5}
                      dot={{ r: 3.5, fill: '#F26A1B' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="mt-6 text-xs text-[var(--text-muted)]">
                No measurements logged yet. Tap Log to track weight progress.
              </p>
            )}
          </div>
          {member.bodyStats.length > 0 && (
            <div className="mt-3 flex items-center justify-between border-t border-[var(--border)] pt-3 text-xs tabular-nums">
              <span className="text-[var(--text-muted)]">Latest Weight</span>
              <span className="font-bold text-[var(--text)]">
                {member.bodyStats[member.bodyStats.length - 1].weightKg} kg
                {member.bodyStats[member.bodyStats.length - 1].bodyFatPct
                  ? ` · ${member.bodyStats[member.bodyStats.length - 1].bodyFatPct}% BF`
                  : ''}
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Payment History */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
        <h3 className="text-sm font-bold text-[var(--text)]">
          Payment History ({memberPayments.length})
        </h3>
        {memberPayments.length === 0 ? (
          <p className="mt-3 text-xs text-[var(--text-muted)]">No payments recorded yet.</p>
        ) : (
          <div className="mt-3 divide-y divide-[var(--border)]">
            {memberPayments.map((p) => (
              <div
                key={p.id}
                onClick={() => setSelectedReceipt(p)}
                className="flex items-center justify-between gap-3 py-3 hover:bg-[var(--bg)]/60 rounded-xl px-2 -mx-2 cursor-pointer transition-colors"
              >
                <div>
                  <p className="text-sm font-semibold text-[var(--text)]">
                    {p.planName} · {p.mode}
                  </p>
                  <p className="text-xs text-[var(--text-muted)] tabular-nums">
                    {p.receiptNo} · {formatDisplayDate(p.date)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-[#1F9D6B] tabular-nums">
                    {formatINR(p.totalPaid)}
                  </p>
                  <p className="text-[11px] text-[var(--text-muted)]">View receipt</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <MemberFormSheet
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editingMember={member}
      />

      <BottomSheet
        open={statOpen}
        onClose={() => setStatOpen(false)}
        title="Log Body Measurement"
        subtitle={member.name}
        desktopMode="modal"
      >
        <form onSubmit={handleLogStat} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1.5">Weight (kg)</label>
            <Input
              type="number"
              step="0.1"
              value={weightKg}
              onChange={(e) => setWeightKg(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1.5">Body Fat %</label>
              <Input
                type="number"
                step="0.1"
                value={bodyFatPct}
                onChange={(e) => setBodyFatPct(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Waist (in)</label>
              <Input
                type="number"
                step="0.1"
                value={waistIn}
                onChange={(e) => setWaistIn(e.target.value)}
              />
            </div>
          </div>
          <Button type="submit" className="w-full">
            Save Measurement
          </Button>
        </form>
      </BottomSheet>

      <ReceiptModal payment={selectedReceipt} onClose={() => setSelectedReceipt(null)} />
    </div>
  );
}
