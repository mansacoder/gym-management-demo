import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Dumbbell, ShieldCheck } from 'lucide-react';
import { useGymStore } from '@/src/store/useGymStore';
import { Button } from '@/src/components/ui/button';

export default function LoginPage() {
  const navigate = useNavigate();
  const loginDemo = useGymStore((s) => s.loginDemo);
  const settings = useGymStore((s) => s.settings);
  const membersCount = useGymStore((s) => s.members.length);

  const handleEnter = () => {
    loginDemo();
    navigate('/dashboard');
  };

  return (
    <div className="min-h-dvh bg-[#121316] text-white flex flex-col justify-between p-6 md:p-12">
      <div className="flex items-center justify-between max-w-5xl w-full mx-auto">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#F26A1B] text-white">
            <Dumbbell className="h-6 w-6" />
          </div>
          <div>
            <p className="text-base font-bold tracking-tight">{settings.gymName}</p>
            <p className="text-xs text-neutral-400">Owner Management Console</p>
          </div>
        </div>
        <span className="text-xs text-neutral-400 hidden sm:inline">
          Indiranagar · Bengaluru
        </span>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-md w-full mx-auto my-12 rounded-3xl border border-white/10 bg-[#181A20] p-7 sm:p-9 shadow-2xl"
      >
        <p className="text-xs font-semibold text-[#F26A1B]">Owner Demo Access</p>
        <h1 className="mt-2 text-2xl sm:text-3xl font-bold tracking-tight text-balance">
          Run your entire gym from one screen.
        </h1>
        <p className="mt-3 text-sm text-neutral-400 leading-relaxed">
          Track {membersCount} members, color-coded fee dues, instant WhatsApp reminders, daily expenses, and monthly net profit.
        </p>

        <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4 flex items-center justify-between">
          <div>
            <p className="text-xs text-neutral-400">Signed in as Owner</p>
            <p className="text-sm font-semibold text-white mt-0.5">{settings.ownerName}</p>
          </div>
          <ShieldCheck className="h-5 w-5 text-[#1F9D6B]" />
        </div>

        <Button
          type="button"
          size="lg"
          className="mt-6 w-full h-12 text-base"
          onClick={handleEnter}
        >
          <span>Open Owner Console</span>
          <ArrowRight className="h-4 w-4" />
        </Button>

        <p className="mt-4 text-center text-xs text-neutral-500">
          One-tap demo · All edits saved locally on this device
        </p>
      </motion.div>

      <div className="max-w-5xl w-full mx-auto flex flex-wrap items-center justify-between gap-3 text-xs text-neutral-500">
        <span>{settings.gymName}</span>
        <span>Members · Fee Recovery · Expenses · Analytics</span>
      </div>
    </div>
  );
}
