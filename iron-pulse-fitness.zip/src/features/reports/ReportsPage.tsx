import { useMemo, useState } from 'react';
import { addMonths, format, isSameMonth, parseISO, startOfMonth, subMonths } from 'date-fns';
import { ChevronLeft, ChevronRight, Download, Printer } from 'lucide-react';
import { toast } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { getFeeStatus } from '@/src/lib/feeStatus';
import { downloadCsv, formatDisplayDate, formatINR } from '@/src/lib/formatters';
import { StatusBadge } from '@/src/components/common/StatusBadge';
import { Button } from '@/src/components/ui/button';

export default function ReportsPage() {
  const settings = useGymStore((s) => s.settings);
  const members = useGymStore((s) => s.members);
  const payments = useGymStore((s) => s.payments);
  const expenses = useGymStore((s) => s.expenses);
  const plans = useGymStore((s) => s.plans);

  const [month, setMonth] = useState(() => startOfMonth(new Date()));

  const report = useMemo(() => {
    const mPayments = payments.filter((p) => isSameMonth(parseISO(p.date), month));
    const mExpenses = expenses.filter((e) => isSameMonth(parseISO(e.date), month));

    const revenue = mPayments.reduce((s, p) => s + p.totalPaid, 0);
    const expenseTotal = mExpenses.reduce((s, e) => s + e.amount, 0);
    const profit = revenue - expenseTotal;

    const newMembers = members.filter((m) => isSameMonth(parseISO(m.joinDate), month)).length;
    const overdueList = members
      .map((m) => ({
        member: m,
        fee: getFeeStatus(m, settings.reminderDays),
        plan: plans.find((p) => p.id === m.planId),
      }))
      .filter((i) => i.fee.status === 'overdue')
      .sort((a, b) => a.fee.daysToDue - b.fee.daysToDue);

    const byMode = (['UPI', 'Cash', 'Card'] as const).map((mode) => ({
      mode,
      count: mPayments.filter((p) => p.mode === mode).length,
      total: mPayments.filter((p) => p.mode === mode).reduce((s, p) => s + p.totalPaid, 0),
    }));

    return {
      revenue,
      expenseTotal,
      profit,
      newMembers,
      leftOrOverdue: overdueList.length,
      overdueList,
      byMode,
      mPayments,
    };
  }, [month, payments, expenses, members, plans, settings.reminderDays]);

  const handleExportDefaulters = () => {
    downloadCsv(
      `iron-pulse-defaulters-${format(month, 'yyyy-MM')}.csv`,
      ['Member Code', 'Name', 'Phone', 'Plan', 'Due Date', 'Status', 'Plan Amount'],
      report.overdueList.map(({ member, fee, plan }) => [
        member.code,
        member.name,
        member.phone,
        plan?.name ?? 'Monthly',
        member.nextDueDate,
        fee.label,
        plan?.price ?? 1500,
      ])
    );
    toast.success('Defaulters CSV exported');
  };

  return (
    <div className="space-y-5">
      {/* Toolbar */}
      <div className="no-print flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMonth((m) => subMonths(m, 1))}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] cursor-pointer"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="min-w-[140px] text-center text-sm font-bold">
            {format(month, 'MMMM yyyy')}
          </span>
          <button
            type="button"
            onClick={() => setMonth((m) => addMonths(m, 1))}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] cursor-pointer"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        <div className="flex items-center gap-2">
          <Button type="button" variant="outline" onClick={handleExportDefaulters}>
            <Download className="h-4 w-4" />
            <span>Defaulters CSV</span>
          </Button>
          <Button type="button" onClick={() => window.print()}>
            <Printer className="h-4 w-4" />
            <span>Download / Print PDF</span>
          </Button>
        </div>
      </div>

      {/* Printable Header */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 print-break-inside-avoid">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-[var(--border)] pb-4">
          <div>
            <h2 className="text-lg font-bold text-[var(--text)]">
              {settings.gymName} — Monthly Business Report
            </h2>
            <p className="text-xs text-[var(--text-muted)]">
              Period: {format(month, 'MMMM yyyy')} · {settings.address}
            </p>
          </div>
          <p className="text-xs text-[var(--text-muted)] tabular-nums">
            Generated {format(new Date(), 'dd MMM yyyy')}
          </p>
        </div>

        <div className="mt-4 grid grid-cols-2 sm:grid-cols-5 gap-4">
          <div>
            <p className="text-xs text-[var(--text-muted)]">Gross Revenue</p>
            <p className="mt-1 text-xl font-bold text-[#1F9D6B] tabular-nums">
              {formatINR(report.revenue)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-muted)]">Total Expenses</p>
            <p className="mt-1 text-xl font-bold text-[var(--text)] tabular-nums">
              {formatINR(report.expenseTotal)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-muted)]">Net Profit</p>
            <p className="mt-1 text-xl font-bold text-[#F26A1B] tabular-nums">
              {formatINR(report.profit)}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-muted)]">New Joinings</p>
            <p className="mt-1 text-xl font-bold text-[var(--text)] tabular-nums">
              {report.newMembers}
            </p>
          </div>
          <div>
            <p className="text-xs text-[var(--text-muted)]">Overdue Accounts</p>
            <p className="mt-1 text-xl font-bold text-[#D6403A] tabular-nums">
              {report.leftOrOverdue}
            </p>
          </div>
        </div>
      </div>

      {/* Collection by Mode */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 print-break-inside-avoid">
        <h3 className="text-sm font-bold text-[var(--text)]">Collection by Payment Mode</h3>
        <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {report.byMode.map((row) => (
            <div
              key={row.mode}
              className="rounded-xl border border-[var(--border)] bg-[var(--bg)]/50 p-3.5 flex items-center justify-between"
            >
              <div>
                <p className="text-xs text-[var(--text-muted)]">{row.mode}</p>
                <p className="text-lg font-bold text-[var(--text)] tabular-nums">
                  {formatINR(row.total)}
                </p>
              </div>
              <span className="text-xs font-semibold text-[var(--text-muted)] tabular-nums">
                {row.count} txns
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Defaulters Table */}
      <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
        <h3 className="text-sm font-bold text-[var(--text)]">
          Fee Defaulters Report ({report.overdueList.length})
        </h3>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[var(--border)] text-[var(--text-muted)]">
                <th className="py-2.5 pr-3">Member</th>
                <th className="py-2.5 px-3">Phone</th>
                <th className="py-2.5 px-3">Plan</th>
                <th className="py-2.5 px-3">Due Date</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 pl-3 text-right">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {report.overdueList.map(({ member, fee, plan }) => (
                <tr key={member.id}>
                  <td className="py-2.5 pr-3 font-semibold text-[var(--text)]">{member.name}</td>
                  <td className="py-2.5 px-3 tabular-nums text-[var(--text-muted)]">
                    {member.phone}
                  </td>
                  <td className="py-2.5 px-3">{plan?.name}</td>
                  <td className="py-2.5 px-3 tabular-nums">
                    {formatDisplayDate(member.nextDueDate)}
                  </td>
                  <td className="py-2.5 px-3">
                    <StatusBadge status={fee.status} label={fee.shortLabel} compact />
                  </td>
                  <td className="py-2.5 pl-3 text-right font-bold tabular-nums">
                    {formatINR(plan?.price ?? 1500)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
