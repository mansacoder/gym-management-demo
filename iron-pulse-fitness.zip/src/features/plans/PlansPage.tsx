import { useState } from 'react';
import { Edit3, Plus, Tag, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import type { MembershipPlan } from '@/src/types';
import { useGymStore } from '@/src/store/useGymStore';
import { formatINR } from '@/src/lib/formatters';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { Button } from '@/src/components/ui/button';
import { Input, Textarea } from '@/src/components/ui/input';

export default function PlansPage() {
  const plans = useGymStore((s) => s.plans);
  const members = useGymStore((s) => s.members);
  const addPlan = useGymStore((s) => s.addPlan);
  const updatePlan = useGymStore((s) => s.updatePlan);
  const deletePlan = useGymStore((s) => s.deletePlan);

  const [sheetOpen, setSheetOpen] = useState(false);
  const [editing, setEditing] = useState<MembershipPlan | null>(null);
  const [name, setName] = useState('');
  const [durationMonths, setDurationMonths] = useState('1');
  const [price, setPrice] = useState('1500');
  const [admissionFee, setAdmissionFee] = useState('500');
  const [description, setDescription] = useState('');
  const [isAddon, setIsAddon] = useState(false);

  const openCreate = () => {
    setEditing(null);
    setName('');
    setDurationMonths('1');
    setPrice('2000');
    setAdmissionFee('500');
    setDescription('');
    setIsAddon(false);
    setSheetOpen(true);
  };

  const openEdit = (plan: MembershipPlan) => {
    setEditing(plan);
    setName(plan.name);
    setDurationMonths(String(plan.durationMonths));
    setPrice(String(plan.price));
    setAdmissionFee(String(plan.admissionFee));
    setDescription(plan.description);
    setIsAddon(Boolean(plan.isAddon));
    setSheetOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error('Enter a plan name');
      return;
    }
    const payload = {
      name: name.trim(),
      durationMonths: Math.max(1, Number(durationMonths) || 1),
      price: Math.max(0, Number(price) || 0),
      admissionFee: Math.max(0, Number(admissionFee) || 0),
      description: description.trim() || 'Standard gym access package',
      isAddon,
      active: true,
    };
    if (editing) {
      updatePlan(editing.id, payload);
      toast.success(`${payload.name} updated`);
    } else {
      addPlan(payload);
      toast.success(`${payload.name} created`);
    }
    setSheetOpen(false);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-[var(--text-muted)]">
          Configure membership tiers, duration cycles, admission fees, and PT add-ons
        </p>
        <Button type="button" onClick={openCreate}>
          <Plus className="h-4 w-4" />
          <span>Add Plan</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map((plan) => {
          const enrolledCount = plan.isAddon
            ? members.filter((m) => m.ptAddon).length
            : members.filter((m) => m.planId === plan.id).length;

          return (
            <div
              key={plan.id}
              className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs font-semibold text-[#F26A1B]">
                      {plan.isAddon
                        ? 'Trainer Add-on'
                        : `${plan.durationMonths} ${plan.durationMonths === 1 ? 'Month' : 'Months'}`}
                    </p>
                    <h2 className="mt-0.5 text-lg font-bold text-[var(--text)]">{plan.name}</h2>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => openEdit(plan)}
                      aria-label={`Edit ${plan.name}`}
                      className="flex h-9 w-9 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[var(--surface-muted)] cursor-pointer"
                    >
                      <Edit3 className="h-4 w-4" />
                    </button>
                    {plans.length > 1 && (
                      <button
                        type="button"
                        onClick={() => {
                          deletePlan(plan.id);
                          toast.success(`${plan.name} removed`);
                        }}
                        aria-label={`Delete ${plan.name}`}
                        className="flex h-9 w-9 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[#D6403A]/10 hover:text-[#D6403A] cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-[var(--text)] tabular-nums">
                    {formatINR(plan.price)}
                  </span>
                  <span className="text-xs text-[var(--text-muted)] tabular-nums">
                    · Admission {formatINR(plan.admissionFee)}
                  </span>
                </div>

                <p className="mt-2.5 text-xs text-[var(--text-muted)] leading-relaxed">
                  {plan.description}
                </p>
              </div>

              <div className="mt-5 flex items-center justify-between border-t border-[var(--border)] pt-3 text-xs">
                <span className="flex items-center gap-1.5 text-[var(--text-muted)] tabular-nums">
                  <Tag className="h-3.5 w-3.5" />
                  <span>{enrolledCount} active members</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    updatePlan(plan.id, { active: !plan.active });
                    toast.success(`${plan.name} ${plan.active ? 'paused' : 'activated'}`);
                  }}
                  className="font-semibold text-[#F26A1B] hover:underline cursor-pointer"
                >
                  {plan.active ? 'Active' : 'Paused'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <BottomSheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        title={editing ? 'Edit Membership Plan' : 'New Membership Plan'}
        desktopMode="modal"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1.5">Plan Name</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Transformation 90 Days"
            />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1.5">Months</label>
              <Input
                type="number"
                min={1}
                value={durationMonths}
                onChange={(e) => setDurationMonths(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Fee (₹)</label>
              <Input
                type="number"
                min={0}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Admission</label>
              <Input
                type="number"
                min={0}
                value={admissionFee}
                onChange={(e) => setAdmissionFee(e.target.value)}
              />
            </div>
          </div>
          <label className="flex items-center justify-between rounded-xl border border-[var(--border)] p-3 cursor-pointer">
            <span className="text-xs font-semibold">Mark as Add-on (e.g. PT / Locker)</span>
            <input
              type="checkbox"
              className="h-4 w-4 accent-[#F26A1B]"
              checked={isAddon}
              onChange={(e) => setIsAddon(e.target.checked)}
            />
          </label>
          <div>
            <label className="block text-xs font-semibold mb-1.5">Description</label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is included in this tier..."
            />
          </div>
          <Button type="submit" className="w-full">
            {editing ? 'Update Plan' : 'Create Plan'}
          </Button>
        </form>
      </BottomSheet>
    </div>
  );
}
