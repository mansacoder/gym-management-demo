import { useMemo, useState } from 'react';
import { format, isSameMonth, parseISO, subMonths } from 'date-fns';
import { Plus, Receipt, Repeat, Trash2 } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { toast } from 'sonner';
import type { ExpenseCategory } from '@/src/types';
import { useGymStore } from '@/src/store/useGymStore';
import { formatDisplayDate, formatINR } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Button } from '@/src/components/ui/button';
import { Select } from '@/src/components/ui/input';
import { EmptyState } from '@/src/components/common/EmptyState';
import { ExpenseFormSheet } from '@/src/features/expenses/ExpenseFormSheet';

const CAT_COLORS = [
  '#121316',
  '#F26A1B',
  '#1F9D6B',
  '#E8B30C',
  '#4A5568',
  '#9C4221',
  '#2C5282',
  '#D6403A',
];

export default function ExpensesPage() {
  const expenses = useGymStore((s) => s.expenses);
  const deleteExpense = useGymStore((s) => s.deleteExpense);

  const [categoryFilter, setCategoryFilter] = useState<'All' | ExpenseCategory>('All');
  const [recurringOnly, setRecurringOnly] = useState(false);
  const [addOpen, setAddOpen] = useState(false);

  const now = new Date();

  const thisMonthTotal = useMemo(
    () =>
      expenses
        .filter((e) => isSameMonth(parseISO(e.date), now))
        .reduce((s, e) => s + e.amount, 0),
    [expenses, now]
  );

  const recurringTotal = useMemo(
    () =>
      expenses
        .filter((e) => isSameMonth(parseISO(e.date), now) && e.recurring)
        .reduce((s, e) => s + e.amount, 0),
    [expenses, now]
  );

  const categoryBreakdown = useMemo(() => {
    const map = new Map<string, number>();
    expenses
      .filter((e) => isSameMonth(parseISO(e.date), now))
      .forEach((e) => {
        map.set(e.category, (map.get(e.category) ?? 0) + e.amount);
      });
    return Array.from(map.entries())
      .map(([name, value], idx) => ({
        name,
        value,
        color: CAT_COLORS[idx % CAT_COLORS.length],
      }))
      .sort((a, b) => b.value - a.value);
  }, [expenses, now]);

  const monthlyTrend = useMemo(() => {
    const rows = [];
    for (let i = 5; i >= 0; i--) {
      const mDate = subMonths(now, i);
      const total = expenses
        .filter((e) => isSameMonth(parseISO(e.date), mDate))
        .reduce((s, e) => s + e.amount, 0);
      rows.push({
        month: format(mDate, 'MMM'),
        amount: total,
      });
    }
    return rows;
  }, [expenses, now]);

  const filtered = useMemo(() => {
    return expenses.filter((e) => {
      if (categoryFilter !== 'All' && e.category !== categoryFilter) return false;
      if (recurringOnly && !e.recurring) return false;
      return true;
    });
  }, [expenses, categoryFilter, recurringOnly]);

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-[var(--text-muted)]">
          Log rent, payroll, utilities, and equipment upkeep — feeds directly into Net Profit
        </p>
        <Button type="button" onClick={() => setAddOpen(true)}>
          <Plus className="h-4 w-4" />
          <span>Add Expense</span>
        </Button>
      </div>

      {/* Summary + Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 flex flex-col justify-between">
          <div>
            <p className="text-xs font-medium text-[var(--text-muted)]">
              {format(now, 'MMMM yyyy')} Spend
            </p>
            <p className="mt-1.5 text-3xl font-bold text-[var(--text)] tabular-nums">
              {formatINR(thisMonthTotal)}
            </p>
            <p className="mt-1 text-xs text-[var(--text-muted)] tabular-nums">
              {formatINR(recurringTotal)} recurring fixed overhead
            </p>
          </div>

          <div className="mt-4 flex items-center gap-4">
            <div className="h-32 w-32 shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryBreakdown}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={32}
                    outerRadius={54}
                    paddingAngle={2}
                  >
                    {categoryBreakdown.map((item) => (
                      <Cell key={item.name} fill={item.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(val) => formatINR(Number(val ?? 0))} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-1.5 text-xs">
              {categoryBreakdown.slice(0, 5).map((cat) => (
                <div key={cat.name} className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-[var(--text-muted)] truncate">
                    <span
                      className="h-2.5 w-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <span className="truncate">{cat.name}</span>
                  </span>
                  <span className="font-semibold tabular-nums">{formatINR(cat.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-2 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <h2 className="text-base font-bold text-[var(--text)]">6-Month Expense Trend</h2>
          <p className="text-xs text-[var(--text-muted)]">Total monthly operating costs</p>
          <div className="mt-4 h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="#8A877E" />
                <YAxis
                  tickFormatter={(v: number) => `₹${Math.round(v / 1000)}k`}
                  tick={{ fontSize: 11 }}
                  width={46}
                  stroke="#8A877E"
                />
                <Tooltip formatter={(val) => [formatINR(Number(val ?? 0)), 'Expenses']} />
                <Bar dataKey="amount" fill="#121316" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-3.5">
        <div className="flex items-center gap-2.5">
          <Select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as 'All' | ExpenseCategory)}
            className="w-44"
          >
            <option value="All">All Categories</option>
            {(['Rent', 'Electricity', 'Salaries', 'Equipment', 'Maintenance', 'Supplements', 'Marketing', 'Other'] as ExpenseCategory[]).map(
              (cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              )
            )}
          </Select>
          <button
            type="button"
            onClick={() => setRecurringOnly((v) => !v)}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-xl border px-3.5 h-11 text-xs font-semibold transition-colors cursor-pointer',
              recurringOnly
                ? 'border-[#F26A1B] bg-[#F26A1B]/12 text-[#F26A1B]'
                : 'border-[var(--border)] text-[var(--text-muted)]'
            )}
          >
            <Repeat className="h-3.5 w-3.5" />
            <span>Recurring only</span>
          </button>
        </div>
        <span className="text-xs text-[var(--text-muted)] tabular-nums">
          Showing {filtered.length} entries
        </span>
      </div>

      {/* Expense List */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Receipt}
          title="No expenses found"
          description="Add your first expense or reset category filters."
          actionLabel="Add Expense"
          onAction={() => setAddOpen(true)}
        />
      ) : (
        <div className="space-y-2.5">
          {filtered.slice(0, 50).map((e) => (
            <div
              key={e.id}
              className="flex items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4"
            >
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-sm font-bold text-[var(--text)] truncate">{e.title}</p>
                  {e.recurring && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#F26A1B]">
                      <Repeat className="h-3 w-3" /> Recurring
                    </span>
                  )}
                </div>
                <p className="mt-0.5 text-xs text-[var(--text-muted)]">
                  {e.category} · {e.mode} · {formatDisplayDate(e.date)}
                  {e.note ? ` · ${e.note}` : ''}
                </p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="text-sm font-bold text-[var(--text)] tabular-nums">
                  {formatINR(e.amount)}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    deleteExpense(e.id);
                    toast.success('Expense deleted');
                  }}
                  aria-label={`Delete ${e.title}`}
                  className="flex h-9 w-9 items-center justify-center rounded-xl text-[var(--text-muted)] hover:bg-[#D6403A]/10 hover:text-[#D6403A] transition-colors cursor-pointer"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <ExpenseFormSheet open={addOpen} onClose={() => setAddOpen(false)} />
    </div>
  );
}
