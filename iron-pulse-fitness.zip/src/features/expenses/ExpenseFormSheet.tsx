import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { toast } from 'sonner';
import type { ExpenseCategory, PaymentMode } from '@/src/types';
import { useGymStore } from '@/src/store/useGymStore';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { Button } from '@/src/components/ui/button';
import { Input, Select, Textarea } from '@/src/components/ui/input';

const CATEGORIES: ExpenseCategory[] = [
  'Rent',
  'Electricity',
  'Salaries',
  'Equipment',
  'Maintenance',
  'Supplements',
  'Marketing',
  'Other',
];

const expenseSchema = z.object({
  title: z.string().min(2, 'Enter expense title'),
  category: z.enum([
    'Rent',
    'Electricity',
    'Salaries',
    'Equipment',
    'Maintenance',
    'Supplements',
    'Marketing',
    'Other',
  ]),
  amount: z.number().positive('Amount must be greater than 0'),
  date: z.string().min(1, 'Select date'),
  mode: z.enum(['UPI', 'Cash', 'Card']),
  recurring: z.boolean(),
  note: z.string().optional(),
});

type ExpenseFormValues = z.infer<typeof expenseSchema>;

interface ExpenseFormSheetProps {
  open: boolean;
  onClose: () => void;
}

export function ExpenseFormSheet({ open, onClose }: ExpenseFormSheetProps) {
  const addExpense = useGymStore((s) => s.addExpense);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ExpenseFormValues>({
    resolver: zodResolver(expenseSchema),
    defaultValues: {
      title: '',
      category: 'Maintenance',
      amount: 1500,
      date: format(new Date(), 'yyyy-MM-dd'),
      mode: 'UPI',
      recurring: false,
      note: '',
    },
  });

  const onSubmit = (values: ExpenseFormValues) => {
    addExpense({
      title: values.title.trim(),
      category: values.category,
      amount: values.amount,
      date: values.date,
      mode: values.mode as PaymentMode,
      recurring: values.recurring,
      note: values.note?.trim() ?? '',
    });
    toast.success(`Expense "${values.title}" recorded`);
    reset();
    onClose();
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title="Add Expense"
      subtitle="Automatically updates monthly Net Profit"
      footer={
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" form="expense-form" className="flex-1">
            Save Expense
          </Button>
        </div>
      }
    >
      <form id="expense-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold mb-1.5">Expense Title</label>
          <Input placeholder="e.g. AC Filter Cleaning & Gas Refill" {...register('title')} />
          {errors.title && <p className="mt-1 text-xs text-[#D6403A]">{errors.title.message}</p>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold mb-1.5">Category</label>
            <Select {...register('category')}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1.5">Amount (₹)</label>
            <Input type="number" min={1} {...register('amount', { valueAsNumber: true })} />
            {errors.amount && (
              <p className="mt-1 text-xs text-[#D6403A]">{errors.amount.message}</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold mb-1.5">Date</label>
            <Input type="date" {...register('date')} />
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1.5">Paid By</label>
            <Select {...register('mode')}>
              <option value="UPI">UPI</option>
              <option value="Cash">Cash</option>
              <option value="Card">Card</option>
            </Select>
          </div>
        </div>

        <label className="flex items-center justify-between rounded-xl border border-[var(--border)] p-3 cursor-pointer">
          <div>
            <p className="text-sm font-semibold text-[var(--text)]">Recurring Monthly</p>
            <p className="text-xs text-[var(--text-muted)]">
              Flag for fixed monthly overhead like rent or payroll
            </p>
          </div>
          <input type="checkbox" className="h-5 w-5 accent-[#F26A1B]" {...register('recurring')} />
        </label>

        <div>
          <label className="block text-xs font-semibold mb-1.5">Note</label>
          <Textarea placeholder="Vendor or bill reference..." {...register('note')} />
        </div>
      </form>
    </BottomSheet>
  );
}
