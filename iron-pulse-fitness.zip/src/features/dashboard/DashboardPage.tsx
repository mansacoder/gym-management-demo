import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  addMonths,
  endOfMonth,
  format,
  isSameMonth,
  parseISO,
  startOfMonth,
  subMonths,
} from 'date-fns';
import {
  CalendarCheck,
  ChevronLeft,
  ChevronRight,
  Clock,
  CreditCard,
  IndianRupee,
  Plus,
  Receipt,
  TrendingUp,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useGymStore } from '@/src/store/useGymStore';
import { getFeeStatus, isExpiringInDays } from '@/src/lib/feeStatus';
import { formatCompactINR, formatDisplayDate, formatINR, formatNumber } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { StatCard } from '@/src/components/common/StatCard';
import { Avatar } from '@/src/components/common/Avatar';
import { StatusBadge } from '@/src/components/common/StatusBadge';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { Button } from '@/src/components/ui/button';
import { MemberFormSheet } from '@/src/features/members/MemberFormSheet';
import { ExpenseFormSheet } from '@/src/features/expenses/ExpenseFormSheet';

type ChartRange = '1m' | '3m' | '6m' | '12m';

const PLAN_COLORS = ['#F26A1B', '#121316', '#1F9D6B', '#E8B30C'];
const MODE_COLORS: Record<string, string> = {
  UPI: '#F26A1B',
  Cash: '#1F9D6B',
  Card: '#121316',
};

export default function DashboardPage() {
  const navigate = useNavigate();
  const members = useGymStore((s) => s.members);
  const payments = useGymStore((s) => s.payments);
  const expenses = useGymStore((s) => s.expenses);
  const plans = useGymStore((s) => s.plans);
  const attendance = useGymStore((s) => s.attendance);
  const settings = useGymStore((s) => s.settings);

  const [selectedMonth, setSelectedMonth] = useState(() => startOfMonth(new Date()));
  const [range, setRange] = useState<ChartRange>('6m');
  const [addMemberOpen, setAddMemberOpen] = useState(false);
  const [addExpenseOpen, setAddExpenseOpen] = useState(false);

  const today = new Date();
  const todayIso = format(today, 'yyyy-MM-dd');
  const isCurrentMonth = isSameMonth(selectedMonth, today);

  // Month-scoped metrics
  const metrics = useMemo(() => {
    const activeMembers = members.filter((m) => m.status !== 'frozen').length;
    const newJoinings = members.filter((m) =>
      isSameMonth(parseISO(m.joinDate), selectedMonth)
    ).length;

    const monthPayments = payments.filter((p) =>
      isSameMonth(parseISO(p.date), selectedMonth)
    );
    const feesCollected = monthPayments.reduce((s, p) => s + p.totalPaid, 0);

    const monthExpenses = expenses.filter((e) =>
      isSameMonth(parseISO(e.date), selectedMonth)
    );
    const totalExpenses = monthExpenses.reduce((s, e) => s + e.amount, 0);
    const netProfit = feesCollected - totalExpenses;

    const pendingTotal = members.reduce((sum, m) => {
      const fee = getFeeStatus(m, settings.reminderDays);
      if (fee.status === 'due-soon' || fee.status === 'overdue') {
        const plan = plans.find((p) => p.id === m.planId);
        return sum + (plan?.price ?? 1500) + (m.ptAddon ? 3500 : 0);
      }
      return sum;
    }, 0);

    return {
      activeMembers,
      newJoinings,
      feesCollected,
      pendingTotal,
      totalExpenses,
      netProfit,
      monthPayments,
    };
  }, [members, payments, expenses, plans, selectedMonth, settings.reminderDays]);

  // Revenue vs Expenses chart series
  const revExpSeries = useMemo(() => {
    if (range === '1m') {
      // Weekly breakdown of selectedMonth
      const buckets = [
        { label: 'Wk 1', revenue: 0, expenses: 0 },
        { label: 'Wk 2', revenue: 0, expenses: 0 },
        { label: 'Wk 3', revenue: 0, expenses: 0 },
        { label: 'Wk 4', revenue: 0, expenses: 0 },
      ];
      payments.forEach((p) => {
        const d = parseISO(p.date);
        if (isSameMonth(d, selectedMonth)) {
          const idx = Math.min(3, Math.floor((d.getDate() - 1) / 7));
          buckets[idx].revenue += p.totalPaid;
        }
      });
      expenses.forEach((e) => {
        const d = parseISO(e.date);
        if (isSameMonth(d, selectedMonth)) {
          const idx = Math.min(3, Math.floor((d.getDate() - 1) / 7));
          buckets[idx].expenses += e.amount;
        }
      });
      return buckets;
    }

    const count = range === '3m' ? 3 : range === '6m' ? 6 : 12;
    const rows = [];
    for (let i = count - 1; i >= 0; i--) {
      const mDate = subMonths(selectedMonth, i);
      const rev = payments
        .filter((p) => isSameMonth(parseISO(p.date), mDate))
        .reduce((s, p) => s + p.totalPaid, 0);
      const exp = expenses
        .filter((e) => isSameMonth(parseISO(e.date), mDate))
        .reduce((s, e) => s + e.amount, 0);
      rows.push({
        label: format(mDate, 'MMM'),
        revenue: rev,
        expenses: exp,
      });
    }
    return rows;
  }, [range, selectedMonth, payments, expenses]);

  // Member Growth series (last 6 months up to selectedMonth)
  const growthSeries = useMemo(() => {
    const count = range === '12m' ? 12 : 6;
    const rows = [];
    for (let i = count - 1; i >= 0; i--) {
      const mEnd = endOfMonth(subMonths(selectedMonth, i));
      const mStr = format(mEnd, 'yyyy-MM-dd');
      const totalByThen = members.filter((m) => m.joinDate <= mStr).length;
      rows.push({
        label: format(mEnd, 'MMM'),
        members: totalByThen,
      });
    }
    return rows;
  }, [members, selectedMonth, range]);

  // Plan Split Donut
  const planSplit = useMemo(() => {
    const core = plans.filter((p) => !p.isAddon);
    return core.map((p, idx) => ({
      name: p.name,
      value: members.filter((m) => m.planId === p.id && m.status !== 'frozen').length,
      color: PLAN_COLORS[idx % PLAN_COLORS.length],
    }));
  }, [members, plans]);

  // Payment Mode Breakdown for selectedMonth
  const modeSplit = useMemo(() => {
    const totals: Record<string, number> = { UPI: 0, Cash: 0, Card: 0 };
    metrics.monthPayments.forEach((p) => {
      totals[p.mode] = (totals[p.mode] ?? 0) + p.totalPaid;
    });
    const grand = Object.values(totals).reduce((a, b) => a + b, 0) || 1;
    return (['UPI', 'Cash', 'Card'] as const).map((mode) => ({
      mode,
      amount: totals[mode],
      pct: Math.round((totals[mode] / grand) * 100),
      color: MODE_COLORS[mode],
    }));
  }, [metrics.monthPayments]);

  // Fee Alerts: Due in 7 days vs Overdue
  const { dueSoonAlerts, overdueAlerts, expiringMembers } = useMemo(() => {
    const enriched = members
      .map((m) => ({
        member: m,
        fee: getFeeStatus(m, settings.reminderDays),
        plan: plans.find((p) => p.id === m.planId),
      }))
      .map((item) => ({
        ...item,
        amount: (item.plan?.price ?? 1500) + (item.member.ptAddon ? 3500 : 0),
      }));

    return {
      dueSoonAlerts: enriched
        .filter((i) => i.fee.status === 'due-soon')
        .sort((a, b) => a.fee.daysToDue - b.fee.daysToDue),
      overdueAlerts: enriched
        .filter((i) => i.fee.status === 'overdue')
        .sort((a, b) => a.fee.daysToDue - b.fee.daysToDue),
      expiringMembers: enriched.filter((i) => isExpiringInDays(i.member, 7)),
    };
  }, [members, plans, settings.reminderDays]);

  const todaysCheckIns = useMemo(() => {
    return attendance
      .filter((a) => a.date === todayIso)
      .sort((a, b) => b.checkInTime.localeCompare(a.checkInTime))
      .slice(0, 6)
      .map((a) => ({
        record: a,
        member: members.find((m) => m.id === a.memberId),
      }))
      .filter((item) => Boolean(item.member));
  }, [attendance, members, todayIso]);

  const recentPayments = useMemo(() => payments.slice(0, 5), [payments]);

  return (
    <div className="space-y-6">
      {/* Month Switcher + Quick Actions */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSelectedMonth((m) => subMonths(m, 1))}
            aria-label="Previous month"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-muted)] cursor-pointer"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <div className="min-w-[148px] text-center rounded-xl border border-[var(--border)] bg-[var(--surface)] px-4 py-2 text-sm font-bold text-[var(--text)]">
            {format(selectedMonth, 'MMMM yyyy')}
          </div>
          <button
            type="button"
            onClick={() => setSelectedMonth((m) => addMonths(m, 1))}
            aria-label="Next month"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-[var(--border)] bg-[var(--surface)] hover:bg-[var(--surface-muted)] cursor-pointer"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          {!isCurrentMonth && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setSelectedMonth(startOfMonth(new Date()))}
            >
              This month
            </Button>
          )}
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <Button type="button" variant="outline" size="sm" onClick={() => setAddMemberOpen(true)}>
            <UserPlus className="h-4 w-4" />
            <span>Add Member</span>
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => setAddExpenseOpen(true)}>
            <Receipt className="h-4 w-4" />
            <span>Add Expense</span>
          </Button>
          <Button type="button" size="sm" onClick={() => navigate('/fees/collect')}>
            <Plus className="h-4 w-4" />
            <span>Collect Fee</span>
          </Button>
        </div>
      </div>

      {/* 6 KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3.5">
        <StatCard
          variant="ink"
          label="Active Members"
          value={metrics.activeMembers}
          formatter={formatNumber}
          subtext={`${members.filter((m) => m.status === 'frozen').length} frozen`}
          icon={Users}
          onClick={() => navigate('/members')}
        />
        <StatCard
          label="New Joinings"
          value={metrics.newJoinings}
          formatter={formatNumber}
          subtext={format(selectedMonth, 'MMM yyyy')}
          icon={UserPlus}
          onClick={() => navigate('/members')}
        />
        <StatCard
          label="Fees Collected"
          value={metrics.feesCollected}
          formatter={formatCompactINR}
          subtext={`${metrics.monthPayments.length} receipts`}
          icon={IndianRupee}
          onClick={() => navigate('/fees')}
        />
        <StatCard
          label="Pending Fees"
          value={metrics.pendingTotal}
          formatter={formatCompactINR}
          subtext={`${overdueAlerts.length} overdue · ${dueSoonAlerts.length} due soon`}
          icon={Clock}
          onClick={() => navigate('/fees')}
        />
        <StatCard
          label="Expenses"
          value={metrics.totalExpenses}
          formatter={formatCompactINR}
          subtext={format(selectedMonth, 'MMM yyyy')}
          icon={Receipt}
          onClick={() => navigate('/expenses')}
        />
        <StatCard
          variant="orange"
          label="Net Profit"
          value={metrics.netProfit}
          formatter={formatCompactINR}
          subtext="Collected − Expenses"
          icon={TrendingUp}
          onClick={() => navigate('/reports')}
        />
      </div>

      {/* Recovery & Today's Activity Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Overdue List */}
        <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-[var(--text)]">
                  Overdue Fees ({overdueAlerts.length})
                </h2>
                <p className="text-xs text-[var(--text-muted)]">
                  Immediate recovery priority · Tap Call or WhatsApp
                </p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => navigate('/fees')}
              >
                View in Fees
              </Button>
            </div>

            <div className="mt-4 divide-y divide-[var(--border)]">
              {overdueAlerts.slice(0, 5).map(({ member, fee, plan, amount }) => (
                <div
                  key={member.id}
                  onClick={() => navigate(`/members/${member.id}`)}
                  className="flex items-center justify-between gap-2.5 py-3 cursor-pointer hover:bg-[var(--bg)]/60 -mx-2 px-2 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={member.name} color={member.avatarColor} size="sm" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[var(--text)] truncate">
                        {member.name}
                      </p>
                      <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-[var(--text-muted)]">
                        <span>{plan?.name}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-[var(--text)] tabular-nums">
                          {formatINR(amount)}
                        </span>
                        <StatusBadge status={fee.status} label={fee.shortLabel} compact />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <CallButton phone={member.phone} name={member.name} />
                    <WhatsAppButton
                      phone={member.phone}
                      name={member.name}
                      amount={amount}
                      dueDate={member.nextDueDate}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Today's Check-ins */}
        <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-[var(--text)]">
                  Today&apos;s Check-ins
                </h2>
                <p className="text-xs text-[var(--text-muted)]">
                  Live floor attendance &amp; active check-ins
                </p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => navigate('/attendance')}
              >
                <CalendarCheck className="h-4 w-4" />
                <span>Open Desk</span>
              </Button>
            </div>
            <div className="mt-4 divide-y divide-[var(--border)]">
              {todaysCheckIns.slice(0, 5).map(({ record, member }) =>
                member ? (
                  <div
                    key={record.id}
                    onClick={() => navigate(`/members/${member.id}`)}
                    className="flex items-center justify-between py-2.5 text-xs cursor-pointer hover:bg-[var(--bg)]/60 rounded-xl px-2 -mx-2 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar name={member.name} color={member.avatarColor} size="sm" />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-[var(--text)] truncate">
                          {member.name}
                        </p>
                        <p className="text-xs text-[var(--text-muted)] tabular-nums">
                          {member.code}
                        </p>
                      </div>
                    </div>
                    <span className="font-semibold text-[var(--text)] tabular-nums">
                      {record.checkInTime}
                    </span>
                  </div>
                ) : null
              )}
            </div>
          </div>

          <div className="mt-4 border-t border-[var(--border)] pt-3 flex items-center justify-between text-xs">
            <span className="text-[var(--text-muted)]">Expiring in 7 days</span>
            <button
              type="button"
              onClick={() => navigate('/fees')}
              className="font-bold text-[#F26A1B] hover:underline cursor-pointer tabular-nums"
            >
              {expiringMembers.length} memberships →
            </button>
          </div>
        </section>
      </div>

      {/* Primary Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Monthly Revenue vs Expenses Bar Chart */}
        <div className="lg:col-span-2 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-[var(--text)]">Revenue vs Expenses</h2>
              <p className="text-xs text-[var(--text-muted)]">
                Cashflow comparison across {range === '1m' ? 'weeks of month' : `last ${range}`}
              </p>
            </div>
            <div className="flex items-center gap-1 rounded-xl bg-[var(--bg)] p-1">
              {(['1m', '3m', '6m', '12m'] as ChartRange[]).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setRange(r)}
                  className={cn(
                    'rounded-lg px-2.5 py-1 text-xs font-semibold uppercase transition-colors cursor-pointer',
                    range === r
                      ? 'bg-[#121316] text-white dark:bg-[#F26A1B]'
                      : 'text-[var(--text-muted)] hover:text-[var(--text)]'
                  )}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revExpSeries} barGap={6}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="label" tick={{ fontSize: 12 }} stroke="#8A877E" />
                <YAxis
                  tickFormatter={(v: number) => `₹${Math.round(v / 1000)}k`}
                  tick={{ fontSize: 11 }}
                  width={46}
                  stroke="#8A877E"
                />
                <Tooltip
                  formatter={(value, name) => [
                    formatINR(Number(value ?? 0)),
                    name === 'revenue' ? 'Fees Collected' : 'Expenses',
                  ]}
                  contentStyle={{
                    borderRadius: '12px',
                    border: '1px solid var(--border)',
                    backgroundColor: 'var(--surface)',
                    color: 'var(--text)',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="revenue" name="revenue" fill="#F26A1B" radius={[6, 6, 0, 0]} />
                <Bar dataKey="expenses" name="expenses" fill="#121316" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Plan Split Donut + Collection Mode */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 flex flex-col justify-between space-y-5">
          <div>
            <h2 className="text-base font-bold text-[var(--text)]">Membership Plan Split</h2>
            <p className="text-xs text-[var(--text-muted)]">Active distribution across plans</p>
            <div className="mt-3 flex items-center gap-4">
              <div className="h-36 w-36 shrink-0">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={planSplit}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={38}
                      outerRadius={60}
                      paddingAngle={3}
                    >
                      {planSplit.map((entry) => (
                        <Cell key={entry.name} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-2 text-xs">
                {planSplit.map((p) => (
                  <div key={p.name} className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2 text-[var(--text-muted)] truncate">
                      <span
                        className="h-2.5 w-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: p.color }}
                      />
                      <span className="truncate">{p.name}</span>
                    </span>
                    <span className="font-bold text-[var(--text)] tabular-nums">{p.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-[var(--border)] pt-4">
            <h3 className="text-xs font-bold text-[var(--text)]">
              Collection by Mode ({format(selectedMonth, 'MMM')})
            </h3>
            <div className="mt-3 space-y-2.5">
              {modeSplit.map((item) => (
                <div key={item.mode} className="space-y-1">
                  <div className="flex justify-between text-xs tabular-nums">
                    <span className="font-medium text-[var(--text)]">{item.mode}</span>
                    <span className="text-[var(--text-muted)]">
                      {formatINR(item.amount)} ({item.pct}%)
                    </span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-[var(--bg)] overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${item.pct}%`, backgroundColor: item.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Member Growth Line + Recent Payments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Member Growth */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <h2 className="text-base font-bold text-[var(--text)]">Member Growth</h2>
          <p className="text-xs text-[var(--text-muted)]">Cumulative roster progression</p>
          <div className="mt-4 h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={growthSeries}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="#8A877E" />
                <YAxis tick={{ fontSize: 11 }} width={34} stroke="#8A877E" />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="members"
                  stroke="#1F9D6B"
                  strokeWidth={2.5}
                  dot={{ r: 3.5, fill: '#1F9D6B' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Payments */}
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[var(--text)]">Recent Payments</h2>
              <p className="text-xs text-[var(--text-muted)]">Latest receipts collected at desk</p>
            </div>
            <Button type="button" variant="ghost" size="sm" onClick={() => navigate('/fees')}>
              <CreditCard className="h-4 w-4" />
              <span>All Receipts</span>
            </Button>
          </div>
          <div className="mt-3 divide-y divide-[var(--border)]">
            {recentPayments.map((p) => (
              <div key={p.id} className="flex items-center justify-between py-3 text-xs">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-[var(--text)] truncate">{p.memberName}</p>
                  <p className="text-[var(--text-muted)] tabular-nums">
                    {p.planName} · {p.mode} · {formatDisplayDate(p.date)}
                  </p>
                </div>
                <span className="text-sm font-bold text-[#1F9D6B] tabular-nums shrink-0">
                  +{formatINR(p.totalPaid)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <MemberFormSheet open={addMemberOpen} onClose={() => setAddMemberOpen(false)} />
      <ExpenseFormSheet open={addExpenseOpen} onClose={() => setAddExpenseOpen(false)} />
    </div>
  );
}
