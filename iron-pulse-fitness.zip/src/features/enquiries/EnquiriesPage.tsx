import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Plus, UserCheck } from 'lucide-react';
import { toast } from 'sonner';
import type { Enquiry, LeadSource, LeadStage, PaymentMode } from '@/src/types';
import { useGymStore } from '@/src/store/useGymStore';
import { formatDisplayDate, formatINR } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { BottomSheet } from '@/src/components/mobile/BottomSheet';
import { Button } from '@/src/components/ui/button';
import { Input, Select, Textarea } from '@/src/components/ui/input';

const STAGES: Array<{ id: LeadStage; label: string }> = [
  { id: 'new', label: 'New' },
  { id: 'contacted', label: 'Contacted' },
  { id: 'trial', label: 'Trial' },
  { id: 'joined', label: 'Joined' },
  { id: 'lost', label: 'Lost' },
];

export default function EnquiriesPage() {
  const navigate = useNavigate();
  const enquiries = useGymStore((s) => s.enquiries);
  const plans = useGymStore((s) => s.plans);
  const trainers = useGymStore((s) => s.trainers);
  const addEnquiry = useGymStore((s) => s.addEnquiry);
  const updateEnquiryStage = useGymStore((s) => s.updateEnquiryStage);
  const convertEnquiryToMember = useGymStore((s) => s.convertEnquiryToMember);

  const corePlans = plans.filter((p) => !p.isAddon);

  const [stageFilter, setStageFilter] = useState<'all' | LeadStage>('all');
  const [addOpen, setAddOpen] = useState(false);
  const [convertTarget, setConvertTarget] = useState<Enquiry | null>(null);
  const [convertTrainer, setConvertTrainer] = useState(trainers[0]?.id ?? 'trn-1');
  const [convertMode, setConvertMode] = useState<PaymentMode>('UPI');

  // New Lead fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [source, setSource] = useState<LeadSource>('Walk-in');
  const [planId, setPlanId] = useState(corePlans[0]?.id ?? 'plan-monthly');
  const [notes, setNotes] = useState('');

  const filtered = useMemo(() => {
    if (stageFilter === 'all') return enquiries;
    return enquiries.filter((e) => e.stage === stageFilter);
  }, [enquiries, stageFilter]);

  const handleAddLead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !/^[6-9]\d{9}$/.test(phone.trim())) {
      toast.error('Enter lead name and valid 10-digit mobile number');
      return;
    }
    addEnquiry({
      name: name.trim(),
      phone: phone.trim(),
      source,
      interestedPlanId: planId,
      stage: 'new',
      notes: notes.trim(),
      followUpDate: format(new Date(), 'yyyy-MM-dd'),
    });
    toast.success(`Lead "${name.trim()}" added`);
    setName('');
    setPhone('');
    setNotes('');
    setAddOpen(false);
  };

  const handleConvert = () => {
    if (!convertTarget) return;
    const newMember = convertEnquiryToMember(convertTarget.id, convertTrainer, convertMode);
    if (newMember) {
      toast.success(`${newMember.name} converted to active member!`);
      setConvertTarget(null);
      navigate(`/members/${newMember.id}`);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-[var(--text-muted)]">
          Walk-ins, Instagram DMs, and referrals — convert trials to members in one tap
        </p>
        <Button type="button" onClick={() => setAddOpen(true)}>
          <Plus className="h-4 w-4" />
          <span>Add Enquiry</span>
        </Button>
      </div>

      {/* Stage Pipeline Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-2">
        <button
          type="button"
          onClick={() => setStageFilter('all')}
          className={cn(
            'rounded-xl px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer',
            stageFilter === 'all'
              ? 'bg-[#121316] text-white dark:bg-[#F26A1B]'
              : 'text-[var(--text-muted)] hover:text-[var(--text)]'
          )}
        >
          All ({enquiries.length})
        </button>
        {STAGES.map((st) => {
          const count = enquiries.filter((e) => e.stage === st.id).length;
          return (
            <button
              key={st.id}
              type="button"
              onClick={() => setStageFilter(st.id)}
              className={cn(
                'rounded-xl px-3.5 py-2 text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer tabular-nums',
                stageFilter === st.id
                  ? 'bg-[#121316] text-white dark:bg-[#F26A1B]'
                  : 'text-[var(--text-muted)] hover:text-[var(--text)]'
              )}
            >
              {st.label} ({count})
            </button>
          );
        })}
      </div>

      {/* Enquiries Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((lead) => {
          const plan = plans.find((p) => p.id === lead.interestedPlanId);
          return (
            <div
              key={lead.id}
              className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4 flex flex-col justify-between gap-4"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="text-base font-bold text-[var(--text)]">{lead.name}</h3>
                    <p className="mt-0.5 text-xs text-[var(--text-muted)] tabular-nums">
                      {lead.source} · Interested in {plan?.name} ({formatINR(plan?.price ?? 1500)})
                    </p>
                  </div>
                  <Select
                    value={lead.stage}
                    onChange={(e) => {
                      updateEnquiryStage(lead.id, e.target.value as LeadStage);
                      toast.success(`Moved ${lead.name} to ${e.target.value}`);
                    }}
                    className="h-9 w-32 text-xs font-semibold"
                    aria-label={`Stage for ${lead.name}`}
                  >
                    {STAGES.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.label}
                      </option>
                    ))}
                  </Select>
                </div>

                {lead.notes && (
                  <p className="mt-2.5 text-xs text-[var(--text-muted)] leading-relaxed">
                    {lead.notes}
                  </p>
                )}
                <p className="mt-2 text-[11px] text-[var(--text-muted)] tabular-nums">
                  Enquired {formatDisplayDate(lead.createdAt)} · Follow-up{' '}
                  {formatDisplayDate(lead.followUpDate)}
                </p>
              </div>

              <div className="flex items-center justify-between gap-2 border-t border-[var(--border)] pt-3">
                <div className="flex items-center gap-1.5">
                  <CallButton phone={lead.phone} name={lead.name} showLabel />
                  <WhatsAppButton
                    phone={lead.phone}
                    name={lead.name}
                    amount={plan?.price ?? 1500}
                    dueDate={lead.followUpDate}
                    customMessage={`Hi ${lead.name.split(' ')[0]}, thanks for visiting IRON PULSE FITNESS! Would you like to book your complimentary workout trial this week?`}
                    showLabel
                  />
                </div>
                {lead.stage !== 'joined' && (
                  <Button
                    type="button"
                    size="sm"
                    onClick={() => setConvertTarget(lead)}
                  >
                    <UserCheck className="h-3.5 w-3.5" />
                    <span>Join</span>
                  </Button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Lead Sheet */}
      <BottomSheet
        open={addOpen}
        onClose={() => setAddOpen(false)}
        title="Add Walk-in / Lead"
        desktopMode="modal"
      >
        <form onSubmit={handleAddLead} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold mb-1.5">Prospect Name</label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rishabh Kulkarni"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1.5">Phone</label>
              <Input
                value={phone}
                maxLength={10}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="98XXXXXXXX"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Source</label>
              <Select value={source} onChange={(e) => setSource(e.target.value as LeadSource)}>
                <option value="Walk-in">Walk-in</option>
                <option value="Instagram">Instagram</option>
                <option value="Referral">Referral</option>
                <option value="Google">Google</option>
              </Select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1.5">Interested Plan</label>
            <Select value={planId} onChange={(e) => setPlanId(e.target.value)}>
              {corePlans.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({formatINR(p.price)})
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="block text-xs font-semibold mb-1.5">Notes</label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Fitness goal, preferred batch time..."
            />
          </div>
          <Button type="submit" className="w-full">
            Save Enquiry
          </Button>
        </form>
      </BottomSheet>

      {/* Convert to Member Sheet */}
      <BottomSheet
        open={Boolean(convertTarget)}
        onClose={() => setConvertTarget(null)}
        title="Convert Lead to Member"
        subtitle={convertTarget?.name}
        desktopMode="modal"
      >
        {convertTarget && (
          <div className="space-y-4">
            <p className="text-xs text-[var(--text-muted)]">
              This creates a member profile for <strong>{convertTarget.name}</strong> and records
              initial fee collection.
            </p>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Assign Trainer</label>
              <Select
                value={convertTrainer}
                onChange={(e) => setConvertTrainer(e.target.value)}
              >
                {trainers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Initial Payment Mode</label>
              <Select
                value={convertMode}
                onChange={(e) => setConvertMode(e.target.value as PaymentMode)}
              >
                <option value="UPI">UPI</option>
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
              </Select>
            </div>
            <Button type="button" className="w-full" onClick={handleConvert}>
              Convert & Open Profile
            </Button>
          </div>
        )}
      </BottomSheet>
    </div>
  );
}
