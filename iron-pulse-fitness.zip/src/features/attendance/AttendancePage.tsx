import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { differenceInCalendarDays, eachDayOfInterval, format, parseISO, subDays } from 'date-fns';
import { CalendarCheck, Check, Search, UserX } from 'lucide-react';
import { toast } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { formatDisplayDate } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Avatar } from '@/src/components/common/Avatar';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { Button } from '@/src/components/ui/button';

export default function AttendancePage() {
  const navigate = useNavigate();
  const members = useGymStore((s) => s.members);
  const plans = useGymStore((s) => s.plans);
  const attendance = useGymStore((s) => s.attendance);
  const checkInMember = useGymStore((s) => s.checkInMember);

  const [query, setQuery] = useState('');
  const today = new Date();
  const todayIso = format(today, 'yyyy-MM-dd');

  const todayMap = useMemo(() => {
    const map = new Map<string, string>();
    attendance.forEach((a) => {
      if (a.date === todayIso) {
        map.set(a.memberId, a.checkInTime);
      }
    });
    return map;
  }, [attendance, todayIso]);

  const quickResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    const active = members.filter((m) => m.status !== 'frozen');
    if (!q) return active.slice(0, 8);
    return active
      .filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.phone.includes(q) ||
          m.code.toLowerCase().includes(q)
      )
      .slice(0, 10);
  }, [members, query]);

  const todaysList = useMemo(() => {
    return attendance
      .filter((a) => a.date === todayIso)
      .sort((a, b) => b.checkInTime.localeCompare(a.checkInTime))
      .map((a) => ({
        record: a,
        member: members.find((m) => m.id === a.memberId),
      }))
      .filter((i) => Boolean(i.member));
  }, [attendance, members, todayIso]);

  // 30-day gym floor attendance heatmap
  const heatmapDays = useMemo(() => {
    const days = eachDayOfInterval({ start: subDays(today, 29), end: today });
    const countMap = new Map<string, number>();
    attendance.forEach((a) => {
      countMap.set(a.date, (countMap.get(a.date) ?? 0) + 1);
    });
    return days.map((d) => {
      const iso = format(d, 'yyyy-MM-dd');
      const count = countMap.get(iso) ?? 0;
      return { date: d, iso, count };
    });
  }, [attendance, today]);

  // Retention: Active members not visited in 7+ days
  const absentRetentionList = useMemo(() => {
    const lastVisitMap = new Map<string, string>();
    attendance.forEach((a) => {
      const prev = lastVisitMap.get(a.memberId);
      if (!prev || a.date > prev) {
        lastVisitMap.set(a.memberId, a.date);
      }
    });

    return members
      .filter((m) => m.status !== 'frozen')
      .map((m) => {
        const lastDate = lastVisitMap.get(m.id);
        const daysAbsent = lastDate
          ? differenceInCalendarDays(today, parseISO(lastDate))
          : 30;
        const plan = plans.find((p) => p.id === m.planId);
        return { member: m, lastDate, daysAbsent, plan };
      })
      .filter((item) => item.daysAbsent >= 7)
      .sort((a, b) => b.daysAbsent - a.daysAbsent);
  }, [members, attendance, plans, today]);

  const handleTapCheckIn = (memberId: string, name: string) => {
    const res = checkInMember(memberId, todayIso);
    if (res.created) {
      toast.success(`${name} checked in at ${res.record.checkInTime}`);
    } else {
      toast.info(`${name} already checked in at ${res.record.checkInTime}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Check-in + Today's Log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[var(--text)]">Quick Desk Check-in</h2>
              <p className="text-xs text-[var(--text-muted)]">
                Search name or tap a member to mark today&apos;s visit
              </p>
            </div>
            <span className="text-xs font-bold text-[#1F9D6B] tabular-nums">
              {todaysList.length} today
            </span>
          </div>

          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-[var(--text-muted)]" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type member name or phone..."
              className="h-11 w-full rounded-xl border border-[var(--border)] bg-[var(--bg)] pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#F26A1B]"
            />
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {quickResults.map((m) => {
              const checkedTime = todayMap.get(m.id);
              return (
                <div
                  key={m.id}
                  className="flex items-center justify-between gap-3 rounded-xl border border-[var(--border)] p-2.5"
                >
                  <div
                    onClick={() => navigate(`/members/${m.id}`)}
                    className="flex items-center gap-3 min-w-0 cursor-pointer"
                  >
                    <Avatar name={m.name} color={m.avatarColor} size="sm" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[var(--text)] truncate">{m.name}</p>
                      <p className="text-xs text-[var(--text-muted)] tabular-nums">{m.phone}</p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    variant={checkedTime ? 'secondary' : 'default'}
                    onClick={() => handleTapCheckIn(m.id, m.name)}
                  >
                    {checkedTime ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-[#1F9D6B]" />
                        <span className="tabular-nums">{checkedTime}</span>
                      </>
                    ) : (
                      <>
                        <CalendarCheck className="h-3.5 w-3.5" />
                        <span>Check In</span>
                      </>
                    )}
                  </Button>
                </div>
              );
            })}
          </div>
        </section>

        {/* Today's Check-ins & 30d Heatmap */}
        <section className="space-y-5">
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
            <h2 className="text-base font-bold text-[var(--text)]">30-Day Floor Footfall</h2>
            <p className="text-xs text-[var(--text-muted)]">Daily check-in density</p>
            <div className="mt-4 grid grid-cols-6 sm:grid-cols-10 gap-2">
              {heatmapDays.map((d) => {
                const intensity =
                  d.count >= 35
                    ? 'bg-[#F26A1B] text-white border-[#F26A1B]'
                    : d.count >= 25
                      ? 'bg-[#F26A1B]/65 text-white border-[#F26A1B]/65'
                      : d.count >= 15
                        ? 'bg-[#F26A1B]/25 text-[var(--text)] border-[#F26A1B]/30'
                        : 'bg-[var(--bg)] text-[var(--text-muted)] border-[var(--border)]';
                return (
                  <div
                    key={d.iso}
                    title={`${formatDisplayDate(d.iso)}: ${d.count} check-ins`}
                    className={cn(
                      'flex flex-col items-center justify-center rounded-xl border py-2 text-[11px] font-bold tabular-nums',
                      intensity
                    )}
                  >
                    <span>{format(d.date, 'd')}</span>
                    <span className="text-[9px] font-medium opacity-80">{d.count}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
            <h2 className="text-base font-bold text-[var(--text)]">
              Checked In Today ({todaysList.length})
            </h2>
            <div className="mt-3 max-h-52 overflow-y-auto divide-y divide-[var(--border)]">
              {todaysList.map(({ record, member }) =>
                member ? (
                  <div
                    key={record.id}
                    onClick={() => navigate(`/members/${member.id}`)}
                    className="flex items-center justify-between py-2.5 text-xs cursor-pointer"
                  >
                    <span className="font-semibold text-[var(--text)]">{member.name}</span>
                    <span className="text-[var(--text-muted)] tabular-nums">
                      {record.checkInTime}
                    </span>
                  </div>
                ) : null
              )}
            </div>
          </div>
        </section>
      </div>

      {/* Retention Feature: Not Visited in 7+ Days */}
      <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5">
        <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#D6403A]/12 text-[#D6403A]">
              <UserX className="h-4 w-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[var(--text)]">
                Not Visited in 7+ Days ({absentRetentionList.length})
              </h2>
              <p className="text-xs text-[var(--text-muted)]">
                Call or message inactive members before they churn
              </p>
            </div>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          {absentRetentionList.slice(0, 12).map(({ member, lastDate, daysAbsent, plan }) => (
            <div
              key={member.id}
              className="flex items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--bg)]/50 p-3.5"
            >
              <div
                onClick={() => navigate(`/members/${member.id}`)}
                className="flex items-center gap-3 min-w-0 cursor-pointer"
              >
                <Avatar name={member.name} color={member.avatarColor} size="sm" />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-[var(--text)] truncate">
                    {member.name}
                  </p>
                  <p className="text-xs text-[#D6403A] font-medium tabular-nums">
                    Absent {daysAbsent} days · Last:{' '}
                    {lastDate ? formatDisplayDate(lastDate) : 'Never'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <CallButton phone={member.phone} name={member.name} />
                <WhatsAppButton
                  phone={member.phone}
                  name={member.name}
                  amount={plan?.price ?? 1500}
                  dueDate={member.nextDueDate}
                  customMessage={`Hi ${member.name.split(' ')[0]}, we missed you at IRON PULSE FITNESS this week! Let us know if you want to schedule a quick trainer check-in.`}
                />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
