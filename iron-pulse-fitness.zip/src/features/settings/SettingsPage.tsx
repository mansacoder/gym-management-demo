import { useState } from 'react';
import { Moon, RotateCcw, Save, Sun } from 'lucide-react';
import { toast } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { fillWhatsAppTemplate } from '@/src/lib/formatters';
import { Button } from '@/src/components/ui/button';
import { Input, Textarea } from '@/src/components/ui/input';
import { PWAInstallButton } from '@/src/components/pwa/PWAInstallButton';

export default function SettingsPage() {
  const settings = useGymStore((s) => s.settings);
  const updateSettings = useGymStore((s) => s.updateSettings);
  const toggleDarkMode = useGymStore((s) => s.toggleDarkMode);
  const resetDemoData = useGymStore((s) => s.resetDemoData);

  const [gymName, setGymName] = useState(settings.gymName);
  const [ownerName, setOwnerName] = useState(settings.ownerName);
  const [phone, setPhone] = useState(settings.phone);
  const [address, setAddress] = useState(settings.address);
  const [reminderDays, setReminderDays] = useState(String(settings.reminderDays));
  const [whatsappTemplate, setWhatsappTemplate] = useState(settings.whatsappTemplate);
  const [confirmReset, setConfirmReset] = useState(false);

  const previewMsg = fillWhatsAppTemplate(whatsappTemplate, {
    name: 'Aarav Sharma',
    amount: 1500,
    date: '2026-11-18',
    gymName,
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      gymName: gymName.trim() || 'IRON PULSE FITNESS',
      ownerName: ownerName.trim() || 'Owner',
      phone: phone.trim(),
      address: address.trim(),
      reminderDays: Math.max(1, Math.min(30, Number(reminderDays) || 7)),
      whatsappTemplate,
    });
    toast.success('Gym settings saved');
  };

  return (
    <div className="max-w-3xl space-y-5">
      <form onSubmit={handleSave} className="space-y-5">
        {/* Gym Profile */}
        <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[var(--text)]">Gym Profile</h2>
              <p className="text-xs text-[var(--text-muted)]">
                Appears on receipts, reports, and WhatsApp messages
              </p>
            </div>
            <PWAInstallButton />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold mb-1.5">Gym Name</label>
              <Input value={gymName} onChange={(e) => setGymName(e.target.value)} />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">Owner Name</label>
              <Input value={ownerName} onChange={(e) => setOwnerName(e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold mb-1.5">Desk Phone</label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div>
              <label className="block text-xs font-semibold mb-1.5">
                Yellow Alert Threshold (Days before due)
              </label>
              <Input
                type="number"
                min={1}
                max={30}
                value={reminderDays}
                onChange={(e) => setReminderDays(e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold mb-1.5">Address</label>
            <Input value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
        </section>

        {/* WhatsApp Template */}
        <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-3">
          <div>
            <h2 className="text-base font-bold text-[var(--text)]">
              WhatsApp Reminder Template
            </h2>
            <p className="text-xs text-[var(--text-muted)]">
              Placeholders: {'{name}'}, {'{amount}'}, {'{date}'}, {'{gymName}'}
            </p>
          </div>
          <Textarea
            value={whatsappTemplate}
            onChange={(e) => setWhatsappTemplate(e.target.value)}
          />
          <div className="rounded-xl bg-[var(--bg)] p-3 text-xs text-[var(--text-muted)]">
            <span className="font-semibold text-[var(--text)]">Live preview: </span>
            {previewMsg}
          </div>
        </section>

        <div className="flex justify-end">
          <Button type="submit">
            <Save className="h-4 w-4" />
            <span>Save Settings</span>
          </Button>
        </div>
      </form>

      {/* Appearance & Demo Data Reset */}
      <section className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-[var(--text)]">Theme Appearance</h3>
            <p className="text-xs text-[var(--text-muted)]">
              Switch between warm off-white daylight and charcoal dark mode
            </p>
          </div>
          <Button type="button" variant="outline" onClick={toggleDarkMode}>
            {settings.darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            <span>{settings.darkMode ? 'Light Mode' : 'Dark Mode'}</span>
          </Button>
        </div>

        <div className="border-t border-[var(--border)] pt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-[var(--text)]">Reset Demo Data</h3>
            <p className="text-xs text-[var(--text-muted)]">
              Restore the initial 120 members, 12-month payments, expenses, and enquiries
            </p>
          </div>
          {!confirmReset ? (
            <Button
              type="button"
              variant="outline"
              onClick={() => setConfirmReset(true)}
            >
              <RotateCcw className="h-4 w-4" />
              <span>Reset Demo Data</span>
            </Button>
          ) : (
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setConfirmReset(false)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={() => {
                  resetDemoData();
                  setConfirmReset(false);
                  toast.success('Demo data restored to fresh state');
                }}
              >
                Confirm Reset
              </Button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
