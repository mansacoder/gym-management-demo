import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format, isSameMonth, parseISO } from 'date-fns';
import { CreditCard, Download, MessageCircle, Plus, Search } from 'lucide-react';
import { toast } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { getFeeStatus } from '@/src/lib/feeStatus';
import { downloadCsv, formatDisplayDate, formatINR } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Avatar } from '@/src/components/common/Avatar';
import { StatusBadge } from '@/src/components/common/StatusBadge';
import { CallButton, WhatsAppButton } from '@/src/components/common/ContactActions';
import { ReceiptModal } from '@/src/components/common/ReceiptModal';
import { Button } from '@/src/components/ui/button';
import type { Payment } from '@/src/types';

type FeeTab = 'due-soon' | 'overdue' | 'all-dues' | 'paid';

export default function FeesPage() {
  const navigate = useNavigate();
  const members = useGymStore((s) => s.members);
  const plans = useGymStore((s) => s.plans);
  const payments = useGymStore((s) => s.payments);
  const settings = useGymStore((s) => s.settings);

  const [tab, setTab] = useState<FeeTab>('overdue');
  const [search, setSearch] = useState('');
  const [modeFilter, setModeFilter] = useState<'All' | 'UPI' | 'Cash' | 'Card'>('All');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [receipt, setReceipt] = useState<Payment | null>(null);

  const now = new Date();

  const memberFeeList = useMemo(() => {
    return members.map((m) => {
      const fee = getFeeStatus(m, settings.reminderDays);
      const plan = plans.find((p) => p.id === m.planId);
      const amount = (plan?.price ?? 1500) + (m.ptAddon ? 3500 : 0);
      return { member: m, fee, plan, amount };
    });
  }, [members, plans, settings.reminderDays]);

  const summary = useMemo(() => {
    const collectedThisMonth = payments
      .filter((p) => isSameMonth(parseISO(p.date), now))
      .reduce((sum, p) => sum + p.totalPaid, 0);

    const dueSoonItems = memberFeeList.filter((i) => i.fee.status === 'due-soon');
    const overdueItems = memberFeeList.filter((i) => i.fee.status === 'overdue');

    return {
      collectedThisMonth,
      dueSoonTotal: dueSoonItems.reduce((s, i) => s + i.amount, 0),
      dueSoonCount: dueSoonItems.length,
      overdueTotal: overdueItems.reduce((s, i) => s + i.amount, 0),
      overdueCount: overdueItems.length,
    };
  }, [payments, memberFeeList, now]);

  const visibleMemberDues = useMemo(() => {
    const q = search.trim().toLowerCase();
    return memberFeeList
      .filter((item) => {
        if (tab === 'due-soon' && item.fee.status !== 'due-soon') return false;
        if (tab === 'overdue' && item.fee.status !== 'overdue') return false;
        if (tab === 'all-dues' && item.fee.status !== 'due-soon' && item.fee.status !== 'overdue') {
          return false;
        }
        if (q) {
          return (
            item.member.name.toLowerCase().includes(q) ||
            item.member.phone.includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => a.fee.daysToDue - b.fee.daysToDue);
  }, [memberFeeList, tab, search]);

  const visiblePayments = useMemo(() => {
    const q = search.trim().toLowerCase();
    return payments.filter((p) => {
      if (modeFilter !== 'All' && p.mode !== modeFilter) return false;
      if (q) {
        return (
          p.memberName.toLowerCase().includes(q) ||
          p.receiptNo.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [payments, modeFilter, search]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleBulkReminders = () => {
    const count = selectedIds.size;
    if (count === 0) {
      toast.info('Select at least one overdue member');
      return;
    }
    toast.success(`Fee reminders queued for ${count} selected members`);
    setSelectedIds(new Set());
  };

  const handleExportCsv = () => {
    downloadCsv(
      `iron-pulse-payments-${format(now, 'yyyy-MM')}.csv`,
      ['Receipt No', 'Date', 'Member', 'Plan', 'Mode', 'Total Paid'],
      visiblePayments.map((p) => [
        p.receiptNo,
        p.date,
        p.memberName,
        p.planName,
        p.mode,
        p.totalPaid,
      ])
    );
    toast.success('Payments CSV downloaded');
  };

  return (
    <div className="space-y-5">
      {/* Header + Collect CTA */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-[var(--text-muted)]">
          Track pending dues, send bulk reminders, and generate GST-ready receipts
        </p>
        <div className="flex items-center gap-2">
          <Button type="button" variant="outline" onClick={handleExportCsv}>
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </Button>
          <Button type="button" onClick={() => navigate('/fees/collect')}>
            <Plus className="h-4 w-4" />
            <span>Collect Fee</span>
          </Button>
        </div>
      </div>

      {/* Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
          <p className="text-xs font-medium text-[var(--text-muted)]">Collected This Month</p>
          <p className="mt-1.5 text-2xl font-bold text-[#1F9D6B] tabular-nums">
            {formatINR(summary.collectedThisMonth)}
          </p>
        </div>
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
          <p className="text-xs font-medium text-[var(--text-muted)]">
            Due in {settings.reminderDays} Days ({summary.dueSoonCount})
          </p>
          <p className="mt-1.5 text-2xl font-bold text-[#C99600] dark:text-[#F5CA3E] tabular-nums">
            {formatINR(summary.dueSoonTotal)}
          </p>
        </div>
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
          <p className="text-xs font-medium text-[var(--text-muted)]">
            Overdue Total ({summary.overdueCount})
          </p>
          <p className="mt-1.5 text-2xl font-bold text-[#D6403A] tabular-nums">
            {formatINR(summary.overdueTotal)}
          </p>
        </div>
      </div>

      {/* Tabs + Search */}
      <div className="flex flex-col gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-3.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'overdue' as FeeTab, label: `Overdue (${summary.overdueCount})` },
            { id: 'due-soon' as FeeTab, label: `Due Soon (${summary.dueSoonCount})` },
            { id: 'all-dues' as FeeTab, label: 'All Pending' },
            { id: 'paid' as FeeTab, label: 'Paid History' },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setTab(t.id);
                setSelectedIds(new Set());
              }}
              className={cn(
                'rounded-xl px-3.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer',
                tab === t.id
                  ? 'bg-[#121316] text-white dark:bg-[#F26A1B]'
                  : 'bg-[var(--bg)] text-[var(--text-muted)] hover:text-[var(--text)]'
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="relative sm:w-64">
          <Search className="absolute left-3 top-3 h-4 w-4 text-[var(--text-muted)]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search member or receipt..."
            className="h-10 w-full rounded-xl border border-[var(--border)] bg-[var(--bg)] pl-9 pr-3 text-xs text-[var(--text)] focus:outline-none focus:ring-2 focus:ring-[#F26A1B]"
          />
        </div>
      </div>

      {/* Bulk Reminder Bar */}
      {tab === 'overdue' && visibleMemberDues.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#D6403A]/25 bg-[#D6403A]/8 px-4 py-3">
          <label className="flex items-center gap-2.5 text-xs font-semibold cursor-pointer">
            <input
              type="checkbox"
              className="h-4 w-4 accent-[#F26A1B]"
              checked={
                visibleMemberDues.length > 0 &&
                selectedIds.size === visibleMemberDues.length
              }
              onChange={(e) => {
                if (e.target.checked) {
                  setSelectedIds(new Set(visibleMemberDues.map((i) => i.member.id)));
                } else {
                  setSelectedIds(new Set());
                }
              }}
            />
            <span>
              {selectedIds.size > 0
                ? `${selectedIds.size} overdue members selected`
                : 'Select all overdue members for bulk reminder'}
            </span>
          </label>
          <Button
            type="button"
            size="sm"
            variant="whatsapp"
            onClick={handleBulkReminders}
            disabled={selectedIds.size === 0}
          >
            <MessageCircle className="h-4 w-4" />
            <span>Send Reminders</span>
          </Button>
        </div>
      )}

      {/* Dues List vs Paid Transactions */}
      {tab !== 'paid' ? (
        <div className="space-y-2.5">
          {visibleMemberDues.map(({ member, fee, plan, amount }) => (
            <div
              key={member.id}
              className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-3.5"
            >
              <div className="flex items-center gap-3 min-w-0">
                {tab === 'overdue' && (
                  <input
                    type="checkbox"
                    aria-label={`Select ${member.name}`}
                    className="h-4 w-4 shrink-0 accent-[#F26A1B]"
                    checked={selectedIds.has(member.id)}
                    onChange={() => toggleSelect(member.id)}
                  />
                )}
                <Avatar name={member.name} color={member.avatarColor} size="sm" />
                <div
                  className="min-w-0 cursor-pointer"
                  onClick={() => navigate(`/members/${member.id}`)}
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-bold text-[var(--text)] truncate">{member.name}</p>
                    <StatusBadge status={fee.status} label={fee.label} compact />
                  </div>
                  <p className="mt-0.5 text-xs text-[var(--text-muted)] tabular-nums">
                    {plan?.name} · Due {formatDisplayDate(member.nextDueDate)} ·{' '}
                    <strong className="text-[var(--text)]">{formatINR(amount)}</strong>
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-1.5 shrink-0">
                <CallButton phone={member.phone} name={member.name} />
                <WhatsAppButton
                  phone={member.phone}
                  name={member.name}
                  amount={amount}
                  dueDate={member.nextDueDate}
                />
                <Button
                  type="button"
                  size="sm"
                  onClick={() => navigate(`/fees/collect?memberId=${member.id}`)}
                >
                  <CreditCard className="h-3.5 w-3.5" />
                  <span>Collect</span>
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex items-center gap-1.5">
            {(['All', 'UPI', 'Cash', 'Card'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setModeFilter(m)}
                className={cn(
                  'rounded-lg px-3 py-1.5 text-xs font-semibold cursor-pointer',
                  modeFilter === m
                    ? 'bg-[#F26A1B] text-white'
                    : 'bg-[var(--surface)] border border-[var(--border)] text-[var(--text-muted)]'
                )}
              >
                {m}
              </button>
            ))}
          </div>

          <div className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--surface)]">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[var(--border)] bg-[var(--bg)] text-xs font-semibold text-[var(--text-muted)]">
                    <th className="py-3 pl-4 pr-3">Receipt</th>
                    <th className="py-3 px-3">Member</th>
                    <th className="py-3 px-3">Plan</th>
                    <th className="py-3 px-3">Mode</th>
                    <th className="py-3 px-3">Date</th>
                    <th className="py-3 pl-3 pr-4 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--border)]">
                  {visiblePayments.slice(0, 60).map((p) => (
                    <tr
                      key={p.id}
                      onClick={() => setReceipt(p)}
                      className="hover:bg-[var(--bg)]/70 cursor-pointer transition-colors"
                    >
                      <td className="py-3 pl-4 pr-3 text-xs font-semibold tabular-nums text-[#F26A1B]">
                        {p.receiptNo}
                      </td>
                      <td className="py-3 px-3 font-medium text-[var(--text)]">{p.memberName}</td>
                      <td className="py-3 px-3 text-xs text-[var(--text-muted)]">{p.planName}</td>
                      <td className="py-3 px-3 text-xs font-semibold">{p.mode}</td>
                      <td className="py-3 px-3 text-xs text-[var(--text-muted)] tabular-nums">
                        {formatDisplayDate(p.date)}
                      </td>
                      <td className="py-3 pl-3 pr-4 text-right font-bold text-[#1F9D6B] tabular-nums">
                        {formatINR(p.totalPaid)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <ReceiptModal payment={receipt} onClose={() => setReceipt(null)} />
    </div>
  );
}
