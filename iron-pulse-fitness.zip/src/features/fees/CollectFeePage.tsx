import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { format } from 'date-fns';
import { ArrowLeft, CheckCircle2, CreditCard, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';
import { useGymStore } from '@/src/store/useGymStore';
import { getFeeStatus } from '@/src/lib/feeStatus';
import { formatDisplayDate, formatINR } from '@/src/lib/formatters';
import { cn } from '@/src/lib/utils';
import { Avatar } from '@/src/components/common/Avatar';
import { StatusBadge } from '@/src/components/common/StatusBadge';
import { ReceiptModal } from '@/src/components/common/ReceiptModal';
import { Button } from '@/src/components/ui/button';
import { Input, Select } from '@/src/components/ui/input';
import type { Payment, PaymentMode } from '@/src/types';

export default function CollectFeePage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedId = searchParams.get('memberId') ?? '';

  const members = useGymStore((s) => s.members);
  const plans = useGymStore((s) => s.plans);
  const settings = useGymStore((s) => s.settings);
  const collectFee = useGymStore((s) => s.collectFee);

  const corePlans = plans.filter((p) => !p.isAddon && p.active);
  const ptPlan = plans.find((p) => p.isAddon);

  const [selectedMemberId, setSelectedMemberId] = useState(preselectedId);
  const [memberSearch, setMemberSearch] = useState('');

  const selectedMember = members.find((m) => m.id === selectedMemberId) ?? null;

  const [planId, setPlanId] = useState(selectedMember?.planId ?? corePlans[0]?.id ?? 'plan-monthly');
  const [discount, setDiscount] = useState('0');
  const [admissionFee, setAdmissionFee] = useState('0');
  const [includePt, setIncludePt] = useState(selectedMember?.ptAddon ?? false);
  const [mode, setMode] = useState<PaymentMode>('UPI');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [note, setNote] = useState('');
  const [createdPayment, setCreatedPayment] = useState<Payment | null>(null);
  const [justPaid, setJustPaid] = useState(false);

  const filteredMembers = useMemo(() => {
    const q = memberSearch.trim().toLowerCase();
    const sorted = [...members].sort((a, b) => {
      const fa = getFeeStatus(a, settings.reminderDays).daysToDue;
      const fb = getFeeStatus(b, settings.reminderDays).daysToDue;
      return fa - fb;
    });
    if (!q) return sorted.slice(0, 12);
    return sorted
      .filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.phone.includes(q) ||
          m.code.toLowerCase().includes(q)
      )
      .slice(0, 12);
  }, [members, memberSearch, settings.reminderDays]);

  const activePlan = corePlans.find((p) => p.id === planId) ?? corePlans[0];
  const discountVal = Math.max(0, Number(discount) || 0);
  const admissionVal = Math.max(0, Number(admissionFee) || 0);
  const ptVal = includePt && ptPlan ? ptPlan.price : 0;
  const totalPayable = Math.max(0, (activePlan?.price ?? 0) + admissionVal + ptVal - discountVal);

  const handleSelectMember = (id: string) => {
    const m = members.find((item) => item.id === id);
    setSelectedMemberId(id);
    if (m) {
      setPlanId(m.planId);
      setIncludePt(m.ptAddon);
    }
  };

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) {
      toast.error('Please select a member first');
      return;
    }
    const payment = collectFee({
      memberId: selectedMember.id,
      planId,
      discount: discountVal,
      admissionFee: admissionVal,
      ptAddonFee: ptVal,
      mode,
      date,
      note,
    });
    setJustPaid(true);
    setCreatedPayment(payment);
    toast.success(`Collected ${formatINR(payment.totalPaid)} from ${selectedMember.name}`);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <Button type="button" variant="outline" size="sm" onClick={() => navigate('/fees')}>
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Fees</span>
        </Button>
      </div>

      {/* Step 1: Select Member */}
      {!selectedMember ? (
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
          <div>
            <h2 className="text-base font-bold text-[var(--text)]">Select Member</h2>
            <p className="text-xs text-[var(--text-muted)]">
              Overdue & due-soon members are listed at the top
            </p>
          </div>
          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-[var(--text-muted)]" />
            <input
              value={memberSearch}
              onChange={(e) => setMemberSearch(e.target.value)}
              placeholder="Search member by name, phone, or IP code..."
              className="h-11 w-full rounded-xl border border-[var(--border)] bg-[var(--bg)] pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-[#F26A1B]"
            />
          </div>
          <div className="space-y-2">
            {filteredMembers.map((m) => {
              const fee = getFeeStatus(m, settings.reminderDays);
              const mPlan = plans.find((p) => p.id === m.planId);
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => handleSelectMember(m.id)}
                  className="flex w-full items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--bg)]/50 p-3 text-left hover:border-[#F26A1B] transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar name={m.name} color={m.avatarColor} size="sm" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[var(--text)] truncate">{m.name}</p>
                      <p className="text-xs text-[var(--text-muted)] tabular-nums">
                        {mPlan?.name} · Due {formatDisplayDate(m.nextDueDate)}
                      </p>
                    </div>
                  </div>
                  <StatusBadge status={fee.status} label={fee.shortLabel} compact />
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <form onSubmit={handleConfirm} className="space-y-4">
          {/* Selected Member Summary */}
          <div className="flex items-center justify-between gap-3 rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-4">
            <div className="flex items-center gap-3 min-w-0">
              <Avatar name={selectedMember.name} color={selectedMember.avatarColor} />
              <div className="min-w-0">
                <p className="text-sm font-bold text-[var(--text)] truncate">
                  {selectedMember.name}
                </p>
                <p className="text-xs text-[var(--text-muted)] tabular-nums">
                  Current Due: {formatDisplayDate(selectedMember.nextDueDate)}
                </p>
              </div>
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedMemberId('');
                setJustPaid(false);
              }}
            >
              Change
            </Button>
          </div>

          {justPaid && (
            <motion.div
              initial={{ scale: 0.96, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center justify-between rounded-2xl border border-[#1F9D6B]/30 bg-[#1F9D6B]/10 p-4 text-[#167952] dark:text-[#3CD296]"
            >
              <div className="flex items-center gap-3">
                <CheckCircle2 className="h-6 w-6 shrink-0" />
                <div>
                  <p className="text-sm font-bold">Fee Collected Successfully</p>
                  <p className="text-xs">Member due date updated across dashboard and alerts.</p>
                </div>
              </div>
              {createdPayment && (
                <Button
                  type="button"
                  size="sm"
                  variant="whatsapp"
                  onClick={() => setCreatedPayment(createdPayment)}
                >
                  View Receipt
                </Button>
              )}
            </motion.div>
          )}

          {/* Fee Breakdown Form */}
          <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] p-5 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1.5">Plan</label>
                <Select value={planId} onChange={(e) => setPlanId(e.target.value)}>
                  {corePlans.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({formatINR(p.price)})
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1.5">Payment Date</label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1.5">Admission Fee (₹)</label>
                <Input
                  type="number"
                  min={0}
                  value={admissionFee}
                  onChange={(e) => setAdmissionFee(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs font-semibold mb-1.5">Discount (₹)</label>
                <Input
                  type="number"
                  min={0}
                  value={discount}
                  onChange={(e) => setDiscount(e.target.value)}
                />
              </div>
            </div>

            {ptPlan && (
              <label className="flex items-center justify-between rounded-xl border border-[var(--border)] p-3.5 cursor-pointer">
                <div>
                  <p className="text-sm font-semibold text-[var(--text)]">
                    Personal Training Add-on
                  </p>
                  <p className="text-xs text-[var(--text-muted)]">
                    Add +{formatINR(ptPlan.price)} coached package
                  </p>
                </div>
                <input
                  type="checkbox"
                  className="h-5 w-5 accent-[#F26A1B]"
                  checked={includePt}
                  onChange={(e) => setIncludePt(e.target.checked)}
                />
              </label>
            )}

            <div>
              <label className="block text-xs font-semibold mb-2">Payment Mode</label>
              <div className="grid grid-cols-3 gap-2.5">
                {(['UPI', 'Cash', 'Card'] as PaymentMode[]).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={cn(
                      'h-11 rounded-xl border text-sm font-semibold transition-colors cursor-pointer',
                      mode === m
                        ? 'border-[#F26A1B] bg-[#F26A1B]/12 text-[#F26A1B]'
                        : 'border-[var(--border)] bg-[var(--bg)] text-[var(--text)]'
                    )}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1.5">Note (optional)</label>
              <Input
                placeholder="e.g. GPay ref #4482, renewed for 3 months"
                value={note}
                onChange={(e) => setNote(e.target.value)}
              />
            </div>

            {/* Total Summary */}
            <div className="rounded-2xl bg-[#121316] p-4 text-white flex items-center justify-between">
              <div>
                <p className="text-xs text-neutral-400">Net Payable Amount</p>
                <p className="text-2xl font-bold tabular-nums">{formatINR(totalPayable)}</p>
              </div>
              <Button type="submit" size="lg">
                <CreditCard className="h-4 w-4" />
                <span>Confirm & Generate Receipt</span>
              </Button>
            </div>
          </div>
        </form>
      )}

      <ReceiptModal
        payment={createdPayment}
        onClose={() => setCreatedPayment(null)}
      />
    </div>
  );
}
